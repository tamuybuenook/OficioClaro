'use client'

import { useEffect, useMemo, useState, useTransition } from 'react'
import { setMyPrice, resetMyPrice, setMyUnitValue, setMyTaskUt, previewMyIpcUpdate, applyMyIpcUpdate } from '@/lib/actions/userPricing'
import { createCustomer, deleteCustomer } from '@/lib/actions/customers'
import { enableTrade, disableTrade } from '@/lib/actions/userTrades'
import { reportTransferPayment } from '@/lib/actions/payments'
import {
  ArrowLeft,
  ArrowRight,
  ArrowUp,
  Banknote,
  Bell,
  BookOpen,
  Calculator,
  Check,
  ChevronRight,
  CircleDollarSign,
  CalendarDays,
  Pencil,
  Trash2,
  Upload,
  ClipboardList,
  FileText,
  Home,
  LayoutDashboard,
  ListChecks,
  MapPin,
  Menu,
  MoreHorizontal,
  Search,
  Settings,
  ShieldCheck,
  SlidersHorizontal,
  Sparkles,
  Users,
  Wrench,
  X,
} from 'lucide-react'

export type Job = {
  id: string
  name: string
  category: string
  unit: string
  base: number
  regional: number
  personal: number
  module: string | null
}

export type AppShellProps = {
  jobs: Job[]
  profile: {
    fullName: string
    phone: string | null
    email: string
    unitValue: number
  }
  customers: { id: string; name: string; phone: string | null; email: string | null; address: string | null }[]
  subscription: { id: string; planName: string; status: string; endDate: string | null } | null
  trades: { all: { id: string; name: string; slug: string }[]; enabledIds: string[]; limit: number | null }
}

const money = (value: number) => `$${value.toLocaleString('es-AR')}`

type View = 'home' | 'prices' | 'my-list' | 'budgets' | 'clients' | 'profile' | 'subscription' | 'payments' | 'admin' | 'users' | 'lists' | 'ipc' | 'reconciliation' | 'trades'

const navItems: { id: View; label: string; icon: typeof Home }[] = [
  { id: 'home', label: 'Inicio', icon: Home },
  { id: 'prices', label: 'Precios', icon: Search },
  { id: 'my-list', label: 'Mi lista', icon: ListChecks },
  { id: 'budgets', label: 'Presupuestos', icon: ClipboardList },
  { id: 'clients', label: 'Mis clientes', icon: Users },
]

function Logo() {
  return <div className="flex items-center gap-2.5"><div className="flex size-9 items-center justify-center rounded-xl bg-[var(--oc-brand)] text-white"><Wrench className="size-4.5" /></div><span className="text-[17px] font-bold tracking-tight text-[var(--oc-brand)]">Oficio<span className="text-[var(--oc-coral)]">Claro</span></span></div>
}

function Badge({ children, tone = 'neutral' }: { children: React.ReactNode; tone?: 'success' | 'warning' | 'neutral' | 'blue' }) {
  const styles = { success: 'bg-[var(--oc-success-bg)] text-[var(--oc-success-text)]', warning: 'bg-[var(--oc-warning-bg)] text-[var(--oc-warning-text)]', neutral: 'bg-[var(--oc-neutral-bg)] text-[var(--oc-neutral-text)]', blue: 'bg-[var(--oc-blue-bg)] text-[var(--oc-blue-text)]' }
  return <span className={`inline-flex items-center rounded-full px-2.5 py-1 text-[11px] font-semibold ${styles[tone]}`}>{children}</span>
}

function PriceCard({ job, onOpen }: { job: Job; onOpen: () => void }) {
  return <button onClick={onOpen} className="group flex w-full flex-col gap-3 rounded-2xl border border-[#e4e8e7] bg-[var(--oc-surface)] p-4 text-left transition hover:border-[#abc5d4] hover:shadow-sm">
    <div className="flex items-start justify-between gap-3"><div><h3 className="font-semibold text-[var(--oc-ink)]">{job.name}</h3><p className="mt-1 text-xs text-[var(--oc-muted)]">{job.category} · {job.unit}</p></div><ChevronRight className="mt-0.5 size-4 text-[#9aa7ac] transition group-hover:translate-x-0.5" /></div>
    <div className="flex items-end justify-between border-t border-[var(--oc-border-soft)] pt-3"><div><p className="text-[11px] text-[var(--oc-muted)]">Mi precio</p><p className="text-xl font-bold tracking-tight text-[var(--oc-brand)]">{money(job.personal)}</p></div><div className="text-right"><p className="text-[11px] text-[var(--oc-muted)]">General</p><p className="text-sm font-semibold text-[var(--oc-ink)]">{money(job.regional)}</p></div></div>
  </button>
}

function SearchBox({ value, onChange, placeholder = 'Buscar un trabajo...' }: { value: string; onChange: (v: string) => void; placeholder?: string }) {
  return <div className="flex h-14 items-center gap-3 rounded-2xl border border-[var(--oc-border)] bg-[var(--oc-surface)] px-4 shadow-sm focus-within:border-[#6593a8] focus-within:ring-4 focus-within:ring-[#dcebf2]"><Search className="size-5 shrink-0 text-[#73858d]" /><input value={value} onChange={(e) => onChange(e.target.value)} placeholder={placeholder} className="min-w-0 flex-1 bg-transparent text-[15px] text-[var(--oc-ink)] outline-none placeholder:text-[#96a2a6]" /><span className="hidden rounded-md bg-[var(--oc-brand-soft)] px-2.5 py-1 text-[10px] font-bold text-[var(--oc-brand)] sm:block">Ir</span></div>
}

function ThemePicker() {
  const [theme, setTheme] = useState<'light' | 'dark' | 'system'>('system')

  useEffect(() => {
    const saved = window.localStorage.getItem('oficioclaro-theme') as 'light' | 'dark' | 'system' | null
    const next = saved || 'system'
    setTheme(next)
    document.documentElement.classList.toggle('dark', next === 'dark' || (next === 'system' && window.matchMedia('(prefers-color-scheme: dark)').matches))
    document.documentElement.classList.toggle('light', next === 'light')
  }, [])

  const updateTheme = (next: 'light' | 'dark' | 'system') => {
    setTheme(next)
    window.localStorage.setItem('oficioclaro-theme', next)
    document.documentElement.classList.toggle('dark', next === 'dark' || (next === 'system' && window.matchMedia('(prefers-color-scheme: dark)').matches))
    document.documentElement.classList.toggle('light', next === 'light')
  }

  return <div className="flex items-center gap-1 rounded-xl border border-[var(--oc-border)] bg-[var(--oc-surface-muted)] p-1" aria-label="Tema de color">
    {([['light', 'Claro'], ['dark', 'Oscuro'], ['system', 'Sistema']] as const).map(([value, label]) => <button key={value} type="button" onClick={() => updateTheme(value)} aria-pressed={theme === value} className={`rounded-lg px-1.5 py-1.5 text-[10px] font-semibold transition sm:px-2 sm:text-[11px] ${value === 'system' ? 'hidden sm:block' : ''} ${theme === value ? 'bg-[var(--oc-surface)] text-[var(--oc-brand)] shadow-sm' : 'text-[var(--oc-muted)] hover:bg-[var(--oc-surface)]'}`}>{label}</button>)}
  </div>
}

function AppHeader({ title, onMenu, name }: { title?: string; onMenu: () => void; name: string }) {
  const initials = name.split(' ').filter(Boolean).slice(0, 2).map((n) => n[0]?.toUpperCase()).join('') || '·'
  return <header className="sticky top-0 z-20 flex h-[72px] items-center justify-between border-b border-[var(--oc-border)] bg-[var(--oc-page)]/95 px-5 backdrop-blur md:px-8"><div className="flex items-center gap-4"><button onClick={onMenu} className="rounded-lg p-2 text-[var(--oc-muted)] hover:bg-[#eef2f1] md:hidden" aria-label="Abrir menú"><Menu className="size-5" /></button><div className="md:hidden"><Logo /></div>{title && <h1 className="hidden text-xl font-bold text-[var(--oc-ink)] md:block">{title}</h1>}</div><div className="flex items-center gap-3"><ThemePicker /><button className="relative rounded-full p-2 text-[#61727a] hover:bg-[#eef2f1]" aria-label="Notificaciones"><Bell className="size-5" /><span className="absolute right-1.5 top-1.5 size-1.5 rounded-full bg-[var(--oc-coral)]" /></button><div className="hidden items-center gap-2 md:flex"><div className="flex size-9 items-center justify-center rounded-full bg-[var(--oc-brand-soft)] text-sm font-bold text-[var(--oc-brand)]">{initials}</div><span className="text-sm font-semibold text-[#ff9b79]">{name}</span></div></div></header>
}

function Sidebar({ view, setView, admin = false }: { view: View; setView: (v: View) => void; admin?: boolean }) {
  const items = admin
    ? [
        { id: 'admin' as View, label: 'Dashboard', icon: LayoutDashboard },
        { id: 'users' as View, label: 'Usuarios', icon: Users },
        { id: 'lists' as View, label: 'Listas maestras', icon: BookOpen, href: '/admin/catalogo' },
        { id: 'ipc' as View, label: 'IPC y actualizaciones', icon: CircleDollarSign },
        { id: 'reconciliation' as View, label: 'Conciliación', icon: Banknote },
      ]
    : navItems

  return (
    <aside className="hidden w-[240px] shrink-0 flex-col border-r border-[var(--oc-border)] bg-[var(--oc-surface-muted)] px-4 py-6 md:flex">
      <div className="px-3"><Logo /></div>
      <div className="mt-10 flex flex-col gap-1">
        {items.map(({ id, label, icon: Icon, href }: { id: View; label: string; icon: any; href?: string }) => (
          href ? (
            <a key={id} href={href} className="oc-nav-button flex cursor-pointer items-center gap-3 rounded-xl px-3 py-3 text-left text-sm font-semibold text-[var(--oc-muted)] transition hover:bg-[var(--oc-surface-soft)]">
              <Icon className="size-[18px]" />{label}
            </a>
          ) : (
            <div key={id} role="button" tabIndex={0} onClick={() => setView(id)} onKeyDown={(event) => { if (event.key === 'Enter' || event.key === ' ') setView(id) }} className={`oc-nav-button flex cursor-pointer items-center gap-3 rounded-xl px-3 py-3 text-left text-sm font-semibold transition ${view === id ? 'bg-[var(--oc-nav-active)] text-[var(--oc-brand)]' : 'text-[var(--oc-muted)] hover:bg-[var(--oc-surface-soft)]'}`}>
              <Icon className="size-[18px]" />{label}
            </div>
          )
        ))}
      </div>
      <div className="mt-auto flex flex-col gap-1 border-t border-[#e1e7e4] pt-4">
        <button type="button" onClick={() => setView('profile')} className="flex items-center gap-3 rounded-xl px-3 py-3 text-sm font-semibold text-[var(--oc-muted)] hover:bg-[var(--oc-surface-soft)]"><Settings className="size-[18px]" />Mi perfil</button>
        <button type="button" onClick={() => setView(admin ? 'home' : 'admin')} className="flex items-center gap-3 rounded-xl px-3 py-3 text-sm font-semibold text-[var(--oc-muted)] hover:bg-[var(--oc-surface-soft)]"><ShieldCheck className="size-[18px]" />{admin ? 'Volver a la app' : 'Panel admin'}</button>
      </div>
    </aside>
  )
}

function BottomNav({ view, setView }: { view: View; setView: (v: View) => void }) { return <nav className="fixed inset-x-0 bottom-0 z-30 grid h-[72px] grid-cols-5 border-t border-[var(--oc-border)] bg-[var(--oc-surface)]/95 px-2 pb-1 backdrop-blur md:hidden">{[...navItems, { id: 'profile' as View, label: 'Más', icon: MoreHorizontal }].map(({ id, label, icon: Icon }) => <button key={id} onClick={() => setView(id)} className={`oc-bottom-nav-button flex flex-col items-center justify-center gap-1 text-[10px] font-semibold ${view === id ? 'text-[var(--oc-brand)]' : 'text-[#849096]'}`}><Icon className="size-[19px]" />{label}</button>)}</nav> }

function HomePage({ setView, setSelected, jobs, subscription, firstName }: { setView: (v: View) => void; setSelected: (j: Job) => void; jobs: Job[]; subscription: AppShellProps['subscription']; firstName: string }) {
  const [query, setQuery] = useState('')
  return <div className="mx-auto max-w-[1040px] p-5 pb-28 md:p-8"><div className="mb-7 flex items-end justify-between"><div><p className="text-sm font-medium text-[var(--oc-muted)]">Miércoles, 16 de septiembre</p><h1 className="mt-1 text-[28px] font-bold tracking-tight text-[var(--oc-ink)]">Hola, <span className="text-[var(--oc-coral)]">{firstName}</span>.</h1></div><Badge tone="success"><Check className="mr-1 size-3" />Lista actualizada</Badge></div><section className="rounded-3xl bg-[var(--oc-brand-strong)] p-5 text-white shadow-[0_12px_30px_rgba(23,63,95,0.14)] md:p-7"><div className="max-w-xl"><p className="text-xs font-semibold uppercase tracking-[0.14em] text-[#a9c5d3]">Tu consulta rápida</p><h2 className="mt-2 text-2xl font-bold tracking-tight md:text-3xl">¿Qué necesitás consultar?</h2><div className="mt-5"><SearchBox value={query} onChange={setQuery} placeholder="Ej: cambio de canilla" /></div>{query && <div className="mt-2 overflow-hidden rounded-2xl bg-[var(--oc-surface)] text-[var(--oc-ink)] shadow-lg">{jobs.filter((j) => `${j.name} ${j.category}`.toLowerCase().includes(query.toLowerCase())).slice(0, 3).map((job) => <button key={job.id} onClick={() => { setSelected(job); setView('prices') }} className="flex w-full items-center justify-between border-b border-[var(--oc-border-soft)] px-4 py-3 text-left last:border-0"><span><span className="block text-sm font-semibold">{job.name}</span><span className="text-xs text-[var(--oc-muted)]">{job.category}</span></span><span className="font-bold text-[var(--oc-brand)]">{money(job.personal)}</span></button>)}</div>}</div></section><section className="mt-7"><div className="mb-3 flex items-center justify-between"><h2 className="font-bold text-[var(--oc-ink)]">Accesos rápidos</h2><span className="text-xs text-[var(--oc-muted)]">Lo más usado</span></div><div className="grid grid-cols-3 gap-2.5 md:max-w-lg md:gap-3"><button onClick={() => setView('prices')} className="flex min-h-[100px] flex-col justify-between rounded-2xl bg-[var(--oc-brand-soft)] p-3.5 text-left text-[var(--oc-brand)] transition hover:bg-[#dceaf0]"><Search className="size-5" /><span className="text-sm font-bold">Consultar<br />precios</span></button><button onClick={() => setView('my-list')} className="flex min-h-[100px] flex-col justify-between rounded-2xl bg-[#f5eee7] p-3.5 text-left text-[#754936] transition hover:bg-[#f1e5db]"><ListChecks className="size-5" /><span className="text-sm font-bold">Mi<br />lista</span></button><button onClick={() => setView('budgets')} className="flex min-h-[100px] flex-col justify-between rounded-2xl bg-[#edf1eb] p-3.5 text-left text-[#47634f] transition hover:bg-[#e3eae1]"><FileText className="size-5" /><span className="text-sm font-bold">Nuevo<br />presupuesto</span></button></div></section><div className="mt-7 grid gap-4 md:grid-cols-2"><div className="rounded-2xl border border-[var(--oc-border)] bg-[var(--oc-surface)] p-5"><div className="flex items-start justify-between"><div><p className="text-xs font-semibold uppercase tracking-wide text-[#8a979a]">Lista vigente</p><p className="mt-1 text-xl font-bold text-[#2f414a]">Octubre 2026</p></div><div className="rounded-xl bg-[#f5eee7] p-2.5 text-[#b56e4e]"><Sparkles className="size-5" /></div></div><div className="mt-5 flex items-center justify-between border-t border-[var(--oc-border-soft)] pt-4 text-sm"><span className="text-[var(--oc-muted)]">IPC utilizado</span><span className="font-bold text-[#344d5a]">{`XX,X %`}</span></div><div className="mt-2 flex items-center justify-between text-sm"><span className="text-[var(--oc-muted)]">Próxima actualización</span><span className="font-semibold text-[#344d5a]">Noviembre 2026</span></div></div><div className="rounded-2xl border border-[var(--oc-border)] bg-[var(--oc-surface)] p-5"><div className="flex items-start justify-between"><div><p className="text-xs font-semibold uppercase tracking-wide text-[#8a979a]">Estado de cuenta</p><p className="mt-1 text-xl font-bold text-[#2f414a]">{subscription?.planName ?? 'Sin plan'}</p></div><Badge tone={subscription?.status === 'active' ? 'success' : 'warning'}>{subscription?.status === 'active' ? 'Activa' : subscription?.status === 'trial' ? 'Prueba' : subscription?.status ?? 'Sin plan'}</Badge></div><div className="mt-5 flex items-center justify-between border-t border-[var(--oc-border-soft)] pt-4 text-sm"><span className="text-[var(--oc-muted)]">Próximo vencimiento</span><span className="font-semibold text-[#344d5a]">{subscription?.endDate ?? '—'}</span></div><button onClick={() => setView('subscription')} className="mt-4 flex items-center gap-1 text-sm font-bold text-[var(--oc-brand)]">Ver mi suscripción <ArrowRight className="size-4" /></button></div></div></div>
}

function Prices({ setView, selected, setSelected, jobs }: { setView: (v: View) => void; selected: Job; setSelected: (j: Job) => void; jobs: Job[] }) {
  const [query, setQuery] = useState('')
  const filtered = useMemo(() => jobs.filter((j) => `${j.name} ${j.category}`.toLowerCase().includes(query.toLowerCase())), [query])
  return <div className="mx-auto max-w-[1040px] p-5 pb-28 md:p-8"><div className="mb-6"><p className="text-sm text-[var(--oc-muted)]">Lista maestra · Octubre 2026</p><h1 className="mt-1 text-2xl font-bold text-[var(--oc-ink)]">Consultar precios</h1></div><SearchBox value={query} onChange={setQuery} /><div className="mt-5 flex items-center justify-between"><p className="text-sm font-semibold text-[var(--oc-muted)]">{filtered.length} trabajos encontrados</p><button className="flex items-center gap-1.5 text-sm font-semibold text-[var(--oc-brand)]"><SlidersHorizontal className="size-4" />Filtrar</button></div><div className="mt-3 flex flex-col gap-3">{filtered.map((job) => <PriceCard key={job.id} job={job} onOpen={() => { setSelected(job); setView('prices-detail' as View) }} />)}{filtered.length === 0 && <div className="rounded-2xl border border-dashed border-[#cfdad6] p-10 text-center"><Search className="mx-auto size-8 text-[#a1afb0]" /><p className="mt-3 font-semibold text-[#52636a]">No encontramos ese trabajo</p><p className="mt-1 text-sm text-[var(--oc-muted)]">Probá con otra palabra, como “canilla” o “calefón”.</p></div>}</div></div>
}

function Detail({ job, setView, unitValue }: { job: Job; setView: (v: View) => void; unitValue: number }) { const [personal, setPersonal] = useState(job.personal); const [pending, startTransition] = useTransition(); return <div className="mx-auto max-w-[720px] p-5 pb-28 md:p-8"><button onClick={() => setView('prices')} className="mb-6 flex items-center gap-2 text-sm font-semibold text-[var(--oc-brand)]"><ArrowLeft className="size-4" />Volver a precios</button><div className="rounded-3xl border border-[var(--oc-border)] bg-[var(--oc-surface)] p-5 md:p-7"><div className="flex items-start justify-between"><div><Badge tone="blue">{job.category}</Badge><h1 className="mt-3 text-2xl font-bold text-[var(--oc-ink)]">{job.name}</h1><p className="mt-1 text-sm text-[var(--oc-muted)]">Unidad: {job.unit}</p></div><div className="rounded-2xl bg-[var(--oc-surface-soft)] p-3 text-[#5d7278]"><Calculator className="size-5" /></div></div><div className="mt-7 rounded-2xl bg-[var(--oc-surface-muted)] p-4"><p className="text-xs text-[#819097]">Precio general (lista de OficioClaro)</p><p className="mt-1 text-xl font-bold text-[#455a63]">{money(job.base)}</p></div><div className="mt-5 rounded-2xl border-2 border-[#e8c7b6] bg-[#fffaf7] p-4"><div className="flex items-center justify-between"><div><p className="text-xs font-semibold text-[#93624d]">MI PRECIO</p><p className="mt-1 text-3xl font-bold tracking-tight text-[#ad6245]">{money(personal)}{pending && '…'}</p></div><button onClick={() => { const value = window.prompt('¿Cuál es tu precio para este trabajo?', String(personal)); if (!value) return; const next = Number(value.replace(/\D/g, '')) || personal; setPersonal(next); startTransition(() => { setMyPrice(job.id, next) }) }} className="rounded-xl bg-[var(--oc-coral)] px-3.5 py-2.5 text-xs font-bold text-white shadow-sm hover:bg-[#cf6c52]">Editar mi precio</button></div></div><div className="mt-6 flex items-center justify-between border-t border-[var(--oc-border-soft)] pt-5"><div><p className="text-xs text-[#819097]">Módulo utilizado</p><p className="mt-1 font-bold text-[var(--oc-ink)]">{job.module ?? '—'}</p></div><div className="text-right"><p className="text-xs text-[#819097]">Valor actual UT</p><p className="mt-1 font-bold text-[var(--oc-ink)]">{money(unitValue)}</p><button onClick={() => { const value = window.prompt('UT propia para esta tarea (vacío = usar la UT general)', job.module ? job.module.replace(' UT', '') : ''); if (value === null) return; const ut = Number(value.replace(',', '.')); if (!ut) return; startTransition(() => { setMyTaskUt(job.id, ut) }) }} className="mt-1 text-[11px] font-bold text-[var(--oc-brand)] underline">Recalcular con mi UT</button></div></div></div></div> }

function MyList({ setView, setSelected, jobs, unitValue }: { setView: (v: View) => void; setSelected: (j: Job) => void; jobs: Job[]; unitValue: number }) { return <div className="mx-auto max-w-[1040px] p-5 pb-28 md:p-8"><div className="mb-6 flex items-end justify-between"><div><p className="text-sm text-[var(--oc-muted)]">Lista vigente · Octubre 2026</p><h1 className="mt-1 text-2xl font-bold text-[var(--oc-ink)]">Mi lista</h1></div></div><div className="mb-5 flex gap-2"><button className="rounded-full bg-[var(--oc-brand)] px-4 py-2 text-xs font-semibold text-white">Todos</button></div><div className="flex flex-col divide-y divide-[var(--oc-border-soft)] rounded-2xl border border-[var(--oc-border)] bg-[var(--oc-surface)]">{jobs.map((job) => <button key={job.id} onClick={() => { setSelected(job); setView('prices' as View) }} className="flex min-h-14 items-center justify-between gap-3 px-3 py-3 text-left transition hover:bg-[var(--oc-surface-muted)] sm:px-4 sm:py-4"><span className="min-w-0"><span className="block truncate text-sm font-semibold text-[var(--oc-ink)]">{job.name}</span><span className="mt-1 block text-xs text-[var(--oc-muted)]">{job.category} · {job.unit}</span></span><span className="shrink-0 text-right"><span className="block text-sm font-bold text-[var(--oc-brand)]">{money(job.personal)}</span><span className="text-[11px] text-[var(--oc-muted)]">Mi precio</span></span></button>)}</div><button onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })} className="fixed bottom-24 right-5 z-10 flex items-center gap-1.5 rounded-full bg-[var(--oc-brand)] px-3 py-2 text-xs font-bold text-white shadow-lg md:bottom-6"><ArrowUp className="size-3.5" />TOP</button><div className="mt-5 flex items-center gap-3 rounded-2xl bg-[#f5eee7] p-4 text-[#754936]"><CircleDollarSign className="size-5 shrink-0" /><div><p className="text-sm font-bold">Tu valor de UT es {money(unitValue)}</p><p className="mt-0.5 text-xs">Al cambiarlo, se actualizan los trabajos vinculados.</p></div><button onClick={() => setView('profile')} className="ml-auto shrink-0 text-xs font-bold underline">Modificar</button></div></div> }

function ClientsUpdated({ customers }: { customers: AppShellProps['customers'] }) {
  const [showForm, setShowForm] = useState(false)
  const [pending, startTransition] = useTransition()

  function handleCreate(formData: FormData) {
    startTransition(() => { createCustomer(formData) })
    setShowForm(false)
  }

  return <div className="mx-auto max-w-[1040px] p-5 pb-28 md:p-8"><div className="flex items-start justify-between"><div><p className="text-sm text-[var(--oc-muted)]">Personas a las que les presupuestás</p><h1 className="mt-1 text-2xl font-bold text-[var(--oc-ink)]">Mis clientes</h1></div><button onClick={() => setShowForm(!showForm)} className="rounded-xl bg-[var(--oc-coral)] px-4 py-2.5 text-sm font-bold text-white">{showForm ? 'Cerrar' : '+ Nuevo cliente'}</button></div>{showForm && <form action={handleCreate} className="mt-6 rounded-2xl border border-[var(--oc-border)] bg-[var(--oc-surface)] p-5"><h2 className="font-bold text-[var(--oc-ink)]">Dar de alta un cliente</h2><div className="mt-4 grid gap-3 sm:grid-cols-2"><input name="name" required className="rounded-xl border border-[var(--oc-border)] bg-transparent px-3 py-3 text-sm text-[var(--oc-ink)] outline-none" placeholder="Nombre y apellido" /><input name="phone" className="rounded-xl border border-[var(--oc-border)] bg-transparent px-3 py-3 text-sm text-[var(--oc-ink)] outline-none" placeholder="Teléfono" /><input name="email" type="email" className="rounded-xl border border-[var(--oc-border)] bg-transparent px-3 py-3 text-sm text-[var(--oc-ink)] outline-none" placeholder="Email" /><input name="address" className="rounded-xl border border-[var(--oc-border)] bg-transparent px-3 py-3 text-sm text-[var(--oc-ink)] outline-none" placeholder="Dirección" /></div><button type="submit" disabled={pending} className="mt-4 rounded-xl bg-[var(--oc-brand)] px-4 py-2.5 text-sm font-bold text-white disabled:opacity-60">Guardar cliente</button></form>}<div className="mt-6 flex flex-col divide-y divide-[var(--oc-border-soft)] rounded-2xl border border-[var(--oc-border)] bg-[var(--oc-surface)]">{customers.length === 0 && <p className="p-5 text-sm text-[var(--oc-muted)]">Todavía no cargaste clientes.</p>}{customers.map((c) => <div key={c.id} className="flex flex-wrap items-center gap-3 px-4 py-4"><div className="flex size-10 items-center justify-center rounded-full bg-[var(--oc-brand-soft)] text-sm font-bold text-[var(--oc-brand)]">{c.name.split(' ').map(n => n[0]).join('')}</div><div className="min-w-0 flex-1"><p className="truncate text-sm font-bold text-[var(--oc-ink)]">{c.name}</p><p className="text-xs text-[var(--oc-muted)]">{[c.address, c.phone].filter(Boolean).join(' · ') || 'Sin datos de contacto'}</p></div><div className="flex items-center gap-2"><button onClick={() => { if (window.confirm(`¿Borrar a ${c.name}?`)) startTransition(() => { deleteCustomer(c.id) }) }} className="flex items-center gap-1.5 rounded-lg border border-[var(--oc-border)] px-2.5 py-2 text-xs font-bold text-[var(--oc-coral)] transition-all duration-200 hover:-translate-y-0.5 hover:border-[var(--oc-coral)] hover:bg-[var(--oc-coral-soft)] hover:shadow-[0_4px_10px_rgba(217,108,78,0.16)] active:translate-y-0"><Trash2 className="size-3.5" />Borrar</button>{c.phone && <a href={`https://wa.me/${c.phone.replace(/\D/g, '')}`} target="_blank" rel="noreferrer" className="rounded-lg border border-[#1fb957] bg-[#25D366] px-3 py-2 text-xs font-bold text-white transition-all duration-200 hover:-translate-y-0.5 hover:border-[#169447] hover:bg-[#20bd5b] hover:shadow-[0_4px_10px_rgba(37,211,102,0.28)] active:translate-y-0">WhatsApp</a>}</div></div>)}</div></div>
}

function IpcAdmin() {
  const [percent, setPercent] = useState('4,2')
  const [period, setPeriod] = useState('2026-08')
  const [published, setPublished] = useState('2026-09-10')
  const [saved, setSaved] = useState(false)
  const application = period === '2026-08' ? 'Octubre 2026' : 'Mes siguiente a la publicación'
  const history = [{ ipc: '4,2 %', period: 'Agosto 2026', published: '10 septiembre 2026', applied: 'Octubre 2026', status: 'Programado' }, { ipc: '3,8 %', period: 'Julio 2026', published: '13 agosto 2026', applied: 'Septiembre 2026', status: 'Aplicado' }]
  return <div className="mx-auto max-w-[1040px] p-5 pb-28 md:p-8"><p className="text-sm text-[var(--oc-muted)]">Administración</p><div className="flex flex-wrap items-end justify-between gap-3"><div><h1 className="mt-1 text-2xl font-bold text-[var(--oc-ink)]">IPC y actualizaciones</h1><p className="mt-1 text-sm text-[var(--oc-muted)]">IPC publicado → actualización futura → nueva Lista Maestra</p></div><button onClick={() => setSaved(false)} className="rounded-xl bg-[var(--oc-coral)] px-4 py-2.5 text-sm font-bold text-white">+ Cargar IPC</button></div><div className="mt-6 grid gap-3 sm:grid-cols-2"><div className="rounded-2xl border border-[var(--oc-border)] bg-[var(--oc-surface)] p-5"><p className="text-xs font-semibold text-[var(--oc-muted)]">Último IPC cargado</p><p className="mt-2 text-3xl font-bold text-[var(--oc-brand)]">4,2 %</p><p className="mt-3 text-sm text-[var(--oc-muted)]">Publicado <strong className="text-[var(--oc-ink)]">10 septiembre 2026</strong></p><p className="mt-1 text-sm text-[var(--oc-muted)]">Aplicado a <strong className="text-[var(--oc-ink)]">Lista Maestra Octubre 2026</strong></p></div><div className="rounded-2xl border border-[var(--oc-border)] bg-[var(--oc-surface)] p-5"><p className="text-xs font-semibold text-[var(--oc-muted)]">Próxima actualización</p><p className="mt-2 text-xl font-bold text-[var(--oc-ink)]">Pendiente</p><p className="mt-2 text-sm text-[var(--oc-muted)]">Se generará cuando confirmes el IPC programado.</p></div></div><section className="mt-5 rounded-2xl border border-[var(--oc-border)] bg-[var(--oc-surface)] p-5"><div className="flex items-center gap-3"><div className="rounded-xl bg-[var(--oc-brand-soft)] p-3 text-[var(--oc-brand)]"><CalendarDays className="size-5" /></div><div><h2 className="font-bold text-[var(--oc-ink)]">Cargar nuevo IPC</h2><p className="text-sm text-[var(--oc-muted)]">El mes de aplicación se calcula automáticamente.</p></div></div><div className="mt-5 grid gap-4 sm:grid-cols-3"><label className="text-sm font-semibold text-[var(--oc-ink)]">IPC publicado<input value={percent} onChange={e => setPercent(e.target.value)} inputMode="decimal" className="mt-2 w-full rounded-xl border border-[var(--oc-border)] bg-transparent px-3 py-3 font-normal text-[var(--oc-ink)] outline-none" placeholder="4,2 %" /></label><label className="text-sm font-semibold text-[var(--oc-ink)]">Mes del IPC<input type="month" value={period} onChange={e => setPeriod(e.target.value)} className="mt-2 w-full rounded-xl border border-[var(--oc-border)] bg-transparent px-3 py-3 font-normal text-[var(--oc-ink)] outline-none" /></label><label className="text-sm font-semibold text-[var(--oc-ink)]">Fecha de publicación<input type="date" value={published} onChange={e => setPublished(e.target.value)} className="mt-2 w-full rounded-xl border border-[var(--oc-border)] bg-transparent px-3 py-3 font-normal text-[var(--oc-ink)] outline-none" /></label></div><div className="mt-5 rounded-xl bg-[var(--oc-brand-soft)] p-4"><p className="text-xs font-semibold uppercase tracking-wide text-[var(--oc-brand)]">Se aplicará a</p><p className="mt-1 text-lg font-bold text-[var(--oc-brand)]">Lista Maestra {application}</p></div><div className="mt-5 rounded-xl border border-[var(--oc-border)] bg-[var(--oc-surface-muted)] p-4"><p className="text-xs font-semibold text-[var(--oc-muted)]">Actualización programada</p><p className="mt-2 text-sm text-[var(--oc-ink)]"><strong>IPC:</strong> {percent || '0'} % · <strong>Período:</strong> {period || 'Sin definir'} · <strong>Publicado:</strong> {published || 'Sin definir'}</p><p className="mt-3 text-xs text-[var(--oc-muted)]">Este IPC se utilizará como referencia para generar la actualización de precios de la Lista Maestra correspondiente al mes de aplicación.</p><div className="mt-4 flex flex-wrap gap-2"><button onClick={() => setSaved(false)} className="rounded-xl border border-[var(--oc-border)] px-4 py-2.5 text-sm font-bold text-[var(--oc-ink)]">Cancelar</button><button onClick={() => setSaved(true)} className="rounded-xl bg-[var(--oc-brand)] px-4 py-2.5 text-sm font-bold text-white">Guardar IPC</button></div>{saved && <p className="mt-3 text-sm font-semibold text-[var(--oc-success-text)]">IPC guardado como programado.</p>}</div></section><section className="mt-5 rounded-2xl border border-[var(--oc-border)] bg-[var(--oc-surface)] p-5"><div className="flex items-center justify-between"><div><h2 className="font-bold text-[var(--oc-ink)]">Historial de IPC</h2><p className="mt-1 text-sm text-[var(--oc-muted)]">Las listas anteriores permanecen intactas.</p></div><button className="flex items-center gap-2 rounded-xl border border-[var(--oc-border)] px-3 py-2 text-xs font-bold text-[var(--oc-ink)]"><Upload className="size-4" />Exportar</button></div><div className="mt-4 overflow-x-auto"><table className="w-full min-w-[680px] text-left text-sm"><thead><tr className="border-b border-[var(--oc-border-soft)] text-xs text-[var(--oc-muted)]"><th className="px-3 py-3">IPC</th><th>Período</th><th>Publicado</th><th>Aplicación</th><th>Estado</th></tr></thead><tbody>{history.map(row => <tr key={row.period} className="border-b border-[var(--oc-border-soft)] last:border-0"><td className="px-3 py-4 font-bold text-[var(--oc-brand)]">{row.ipc}</td><td className="text-[var(--oc-ink)]">{row.period}</td><td className="text-[var(--oc-muted)]">{row.published}</td><td className="text-[var(--oc-ink)]">{row.applied}</td><td><Badge tone={row.status === 'Aplicado' ? 'success' : 'blue'}>{row.status}</Badge></td></tr>)}</tbody></table></div></section><section className="mt-5 rounded-2xl border border-[var(--oc-border)] bg-[var(--oc-surface)] p-5"><h2 className="font-bold text-[var(--oc-ink)]">Previsualizar actualización</h2><p className="mt-1 text-sm text-[var(--oc-muted)]">Vista previa: no modifica ninguna lista hasta que se confirme.</p><div className="mt-4 grid gap-3 sm:grid-cols-4"><div><p className="text-xs text-[var(--oc-muted)]">Precio actual</p><p className="mt-1 font-bold text-[var(--oc-ink)]">$50.000</p></div><div><p className="text-xs text-[var(--oc-muted)]">IPC aplicado</p><p className="mt-1 font-bold text-[var(--oc-brand)]">{percent || '0'} %</p></div><div><p className="text-xs text-[var(--oc-muted)]">Nuevo precio</p><p className="mt-1 font-bold text-[var(--oc-ink)]">$52.100</p></div><div><p className="text-xs text-[var(--oc-muted)]">Diferencia</p><p className="mt-1 font-bold text-[var(--oc-success-text)]">+$2.100</p></div></div><button onClick={() => setSaved(true)} className="mt-5 rounded-xl bg-[var(--oc-coral)] px-4 py-2.5 text-sm font-bold text-white">Generar actualización</button></section></div>
}

function AdminData({ type }: { type: 'lists' | 'ipc' }) { const isIpc = type === 'ipc'; return <div className="mx-auto max-w-[1040px] p-5 pb-28 md:p-8"><p className="text-sm text-[var(--oc-muted)]">Administración</p><h1 className="mt-1 text-2xl font-bold text-[var(--oc-ink)]">{isIpc ? 'Carga de IPC' : 'Importar listas'}</h1><div className="mt-7 rounded-2xl border border-[var(--oc-border)] bg-[var(--oc-surface)] p-5"><div className="flex items-center gap-3"><div className="rounded-xl bg-[var(--oc-brand-soft)] p-3 text-[var(--oc-brand)]">{isIpc ? <CircleDollarSign className="size-5" /> : <FileText className="size-5" />}</div><div><h2 className="font-bold text-[var(--oc-ink)]">{isIpc ? 'Actualizar índice de precios' : 'Cargar una lista automáticamente'}</h2><p className="mt-1 text-sm text-[var(--oc-muted)]">{isIpc ? 'Subí el archivo con los valores IPC para recalcular referencias.' : 'Importá un CSV o Excel y revisá los cambios antes de publicarlos.'}</p></div></div><label className="mt-6 flex min-h-32 cursor-pointer flex-col items-center justify-center rounded-xl border-2 border-dashed border-[var(--oc-border)] bg-[var(--oc-surface-muted)] text-center"><input type="file" accept=".csv,.xlsx,.xls" className="sr-only" /><span className="text-sm font-bold text-[var(--oc-ink)]">Seleccionar archivo</span><span className="mt-1 text-xs text-[var(--oc-muted)]">CSV o Excel · hasta 10 MB</span></label><button className="mt-4 rounded-xl bg-[var(--oc-brand)] px-4 py-2.5 text-sm font-bold text-white">{isIpc ? 'Validar IPC' : 'Previsualizar importación'}</button></div></div> }

function SimplePage({ title, eyebrow, icon: Icon, children, action }: { title: string; eyebrow?: string; icon: typeof Home; children?: React.ReactNode; action?: string }) { return <div className="mx-auto max-w-[1040px] p-5 pb-28 md:p-8"><div className="flex items-start justify-between"><div><p className="text-sm text-[var(--oc-muted)]">{eyebrow || 'OficioClaro'}</p><h1 className="mt-1 text-2xl font-bold text-[var(--oc-ink)]">{title}</h1></div>{action && <button className="rounded-xl bg-[var(--oc-coral)] px-4 py-2.5 text-sm font-bold text-white">{action}</button>}</div><div className="mt-7">{children || <div className="rounded-2xl border border-dashed border-[#cfdad6] p-10 text-center"><Icon className="mx-auto size-9 text-[#9aabad]" /><p className="mt-3 font-semibold text-[var(--oc-ink)]">Esta sección está lista para conectar</p><p className="mt-1 text-sm text-[var(--oc-muted)]">La experiencia base ya está preparada para tus datos reales.</p></div>}</div></div> }

function Admin({ view, setView }: { view: View; setView: (v: View) => void }) { const stats = [['Usuarios activos', '1.284', Users], ['Pagos pendientes', '43', Banknote], ['A conciliar', '17', CircleDollarSign], ['Próxima actualización', '01/10/26', Sparkles]] as const; return <div className="mx-auto max-w-[1100px] p-5 pb-28 md:p-8"><div><p className="text-sm text-[var(--oc-muted)]">Administración</p><h1 className="mt-1 text-2xl font-bold text-[var(--oc-ink)]">Panel general</h1></div><div className="mt-7 grid grid-cols-2 gap-3 lg:grid-cols-4">{stats.map(([label, value, Icon]) => <div key={label} className="rounded-2xl border border-[var(--oc-border)] bg-[var(--oc-surface)] p-4"><Icon className="size-5 text-[var(--oc-brand)]" /><p className="mt-5 text-xs text-[var(--oc-muted)]">{label}</p><p className="mt-1 text-xl font-bold text-[var(--oc-ink)]">{value}</p></div>)}</div><div className="mt-6 grid gap-4 lg:grid-cols-2"><div className="rounded-2xl border border-[var(--oc-border)] bg-[var(--oc-surface)] p-5"><div className="flex items-center justify-between"><h2 className="font-bold text-[var(--oc-ink)]">Actividad reciente</h2><button className="text-xs font-semibold text-[var(--oc-brand)]">Ver todo</button></div><div className="mt-4 flex flex-col gap-4">{[['María González', 'Envió un comprobante', 'Hace 12 min'], ['Lista de Gasista', 'Actualización creada', 'Hace 1 h'], ['Carlos López', 'Nuevo usuario', 'Hace 2 h']].map(([name, event, time]) => <div key={name} className="flex items-center gap-3"><div className="flex size-9 items-center justify-center rounded-full bg-[var(--oc-brand-soft)] text-xs font-bold text-[var(--oc-brand)]">{name.split(' ').map((n) => n[0]).join('')}</div><div className="min-w-0 flex-1"><p className="truncate text-sm font-semibold text-[var(--oc-ink)]">{name}</p><p className="text-xs text-[var(--oc-muted)]">{event}</p></div><span className="text-[11px] text-[var(--oc-muted)]">{time}</span></div>)}</div></div><div className="rounded-2xl border border-[var(--oc-border)] bg-[var(--oc-surface)] p-5"><h2 className="font-bold text-[var(--oc-ink)]">Tareas para hoy</h2><div className="mt-4 flex flex-col gap-3">{[['Conciliar pagos pendientes', '17 comprobantes', 'reconciliation'], ['Revisar próxima lista', 'Octubre 2026', 'lists'], ['Cargar nuevo índice IPC', 'Agosto 2026', 'ipc']].map(([label, detail, id]) => id === 'lists' ? <a key={label} href="/admin/catalogo" className="flex items-center gap-3 rounded-xl bg-[var(--oc-surface-muted)] p-3 text-left hover:bg-[#edf2ef]"><div className="flex size-9 items-center justify-center rounded-lg bg-[var(--oc-surface)] text-[#66828f]"><Check className="size-4" /></div><div className="flex-1"><p className="text-sm font-semibold text-[var(--oc-ink)]">{label}</p><p className="text-xs text-[var(--oc-muted)]">{detail}</p></div><ChevronRight className="size-4 text-[#a2adaf]" /></a> : <button key={label} onClick={() => setView(id as View)} className="flex items-center gap-3 rounded-xl bg-[var(--oc-surface-muted)] p-3 text-left hover:bg-[#edf2ef]"><div className="flex size-9 items-center justify-center rounded-lg bg-[var(--oc-surface)] text-[#66828f]"><Check className="size-4" /></div><div className="flex-1"><p className="text-sm font-semibold text-[var(--oc-ink)]">{label}</p><p className="text-xs text-[var(--oc-muted)]">{detail}</p></div><ChevronRight className="size-4 text-[#a2adaf]" /></button>)}</div></div></div></div> }

function Profile({ setView, profile, subscription }: { setView: (v: View) => void; profile: AppShellProps['profile']; subscription: AppShellProps['subscription'] }) {
  const [pending, startTransition] = useTransition()
  const initials = profile.fullName.split(' ').filter(Boolean).slice(0, 2).map(n => n[0]?.toUpperCase()).join('') || '·'

  async function handleIpcUpdate() {
    const preview = await previewMyIpcUpdate()
    if ('error' in preview) { window.alert(preview.error); return }
    const { ipcId, ipcValue, period, currentUt, newUt, customPricesCount } = preview.data
    const extra = customPricesCount > 0 ? ` y ${customPricesCount} precio(s) personalizado(s)` : ''
    const ok = window.confirm(`IPC ${period}: ${ipcValue}%.\nTu UT${extra} se actualizarían ${ipcValue}%.\nUT: ${money(currentUt)} → ${money(newUt)}.\n¿Confirmás el ajuste?`)
    if (!ok) return
    startTransition(() => { applyMyIpcUpdate(ipcId, newUt, ipcValue) })
  }
  const rows: [string, string][] = [
    ['Teléfono', profile.phone || '—'],
    ['Email', profile.email],
  ]
  return <div className="mx-auto max-w-[760px] p-5 pb-28 md:p-8"><p className="text-sm text-[var(--oc-muted)]">Cuenta</p><h1 className="mt-1 text-2xl font-bold text-[var(--oc-ink)]">Mi perfil</h1><div className="mt-7 rounded-2xl border border-[var(--oc-border)] bg-[var(--oc-surface)] p-5"><div className="flex items-center gap-4"><div className="flex size-16 items-center justify-center rounded-full bg-[#f1d9c9] text-xl font-bold text-[#744838]">{initials}</div><div><h2 className="font-bold text-[var(--oc-ink)]">{profile.fullName}</h2></div></div><div className="mt-6 grid gap-4 border-t border-[var(--oc-border-soft)] pt-5 sm:grid-cols-2">{rows.map(([label, value]) => <div key={label}><p className="text-xs text-[var(--oc-muted)]">{label}</p><p className="mt-1 text-sm font-semibold text-[var(--oc-ink)]">{value}</p></div>)}</div></div><div className="mt-4 grid gap-4 sm:grid-cols-2"><button onClick={() => setView('trades')} className="flex items-center justify-between rounded-2xl border border-[var(--oc-border)] bg-[var(--oc-surface)] p-4 text-left"><span><span className="block text-xs text-[var(--oc-muted)]">Mis oficios</span><span className="mt-1 block font-bold text-[var(--oc-ink)]">Administrar actividades</span></span><ChevronRight className="size-4 text-[var(--oc-muted)]" /></button><button onClick={() => setView('subscription')} className="flex items-center justify-between rounded-2xl border border-[var(--oc-border)] bg-[var(--oc-surface)] p-4 text-left"><span><span className="block text-xs text-[var(--oc-muted)]">Suscripción</span><span className="mt-1 block font-bold text-[var(--oc-ink)]">{subscription ? `${subscription.planName} · ${subscription.status === 'active' ? 'Activa' : subscription.status}` : 'Sin plan'}</span></span><ChevronRight className="size-4 text-[var(--oc-muted)]" /></button><button onClick={() => { const value = window.prompt('Nuevo valor de tu UT', String(profile.unitValue)); if (!value) return; const next = Number(value.replace(/\D/g, '')); if (next > 0) startTransition(() => { setMyUnitValue(next) }) }} className="flex items-center justify-between rounded-2xl border border-[var(--oc-border)] bg-[var(--oc-surface)] p-4 text-left"><span><span className="block text-xs text-[var(--oc-muted)]">Mi valor de UT</span><span className="mt-1 block font-bold text-[var(--oc-ink)]">{money(profile.unitValue)}{pending && '…'}</span></span><ChevronRight className="size-4 text-[var(--oc-muted)]" /></button><button onClick={handleIpcUpdate} className="flex items-center justify-between rounded-2xl border border-dashed border-[var(--oc-brand)] bg-[var(--oc-brand-soft)] p-4 text-left sm:col-span-2"><span><span className="block text-xs text-[var(--oc-brand)]">Actualizar mi UT por IPC</span><span className="mt-1 block text-xs text-[#557985]">Te mostramos el ajuste antes de aplicarlo</span></span><ChevronRight className="size-4 text-[var(--oc-brand)]" /></button></div></div>
}

function MisOficios({ setView, trades }: { setView: (v: View) => void; trades: AppShellProps['trades'] }) {
  const [pending, startTransition] = useTransition()
  const [error, setError] = useState<string | null>(null)
  const enabledSet = new Set(trades.enabledIds)
  const atLimit = trades.limit !== null && trades.enabledIds.length >= trades.limit

  function toggle(tradeId: string, isEnabled: boolean) {
    setError(null)
    startTransition(async () => {
      const res = isEnabled ? await disableTrade(tradeId) : await enableTrade(tradeId)
      if (res && 'error' in res && res.error) setError(res.error)
    })
  }

  return <div className="mx-auto max-w-[720px] p-5 pb-28 md:p-8">
    <p className="text-sm text-[var(--oc-muted)]">Cuenta</p>
    <h1 className="mt-1 text-2xl font-bold text-[var(--oc-ink)]">Mis oficios</h1>
    <p className="mt-1 text-sm text-[var(--oc-muted)]">{trades.limit === null ? 'Tu plan permite todos los oficios.' : `Tu plan permite hasta ${trades.limit} oficio(s) · tenés ${trades.enabledIds.length}.`}</p>
    {error && <p className="mt-3 rounded-xl bg-[#fdecea] p-3 text-sm font-semibold text-[var(--oc-coral)]">{error}</p>}
    <div className="mt-5 flex flex-col divide-y divide-[var(--oc-border-soft)] rounded-2xl border border-[var(--oc-border)] bg-[var(--oc-surface)]">
      {trades.all.map((trade) => {
        const isEnabled = enabledSet.has(trade.id)
        return <div key={trade.id} className="flex items-center justify-between px-4 py-4">
          <span className="text-sm font-semibold text-[var(--oc-ink)]">{trade.name}</span>
          {isEnabled ? (
            <button disabled={pending} onClick={() => toggle(trade.id, true)} className="rounded-lg border border-[var(--oc-border)] px-3 py-1.5 text-xs font-bold text-[var(--oc-muted)] disabled:opacity-60">✓ Activo</button>
          ) : atLimit ? (
            <button onClick={() => setView('subscription')} className="text-xs font-bold text-[var(--oc-brand)] underline">Ver planes</button>
          ) : (
            <button disabled={pending} onClick={() => toggle(trade.id, false)} className="rounded-lg bg-[var(--oc-brand)] px-3 py-1.5 text-xs font-bold text-white disabled:opacity-60">+ Agregar</button>
          )}
        </div>
      })}
    </div>
  </div>
}

export function AppShell({ jobs, profile, customers, subscription, trades }: AppShellProps) {
  const [view, setView] = useState<View>('home')
  const [selected, setSelected] = useState<Job | null>(jobs[0] ?? null)
  const [menuOpen, setMenuOpen] = useState(false)
  const [payPending, startPayTransition] = useTransition()
  const isAdmin = ['admin', 'users', 'lists', 'ipc', 'reconciliation'].includes(view)
  const firstName = profile.fullName.split(' ')[0] || profile.fullName
  const noTrades = trades.enabledIds.length === 0

  function handleReportPayment(formData: FormData) {
    if (!subscription) return
    startPayTransition(() => { reportTransferPayment(subscription.id, formData) })
  }

  const render = () => {
    if ((view === 'prices' || (view as string) === 'prices-detail' || view === 'my-list') && noTrades) {
      return <div className="mx-auto max-w-md p-8 pb-28 text-center"><p className="font-bold text-[var(--oc-ink)]">Todavía no agregaste ningún oficio.</p><p className="mt-1 text-sm text-[var(--oc-muted)]">Activá tu actividad para ver y personalizar tu lista de precios.</p><button onClick={() => setView('trades')} className="mt-4 rounded-xl bg-[var(--oc-brand)] px-4 py-2.5 text-sm font-bold text-white">Ir a Mis oficios</button></div>
    }
    if (view === 'trades') return <MisOficios setView={setView} trades={trades} />
    if (view === 'home') return <HomePage setView={setView} setSelected={setSelected} jobs={jobs} subscription={subscription} firstName={firstName} />
    if (view === 'prices') return <Prices setView={setView} selected={selected!} setSelected={setSelected} jobs={jobs} />
    if ((view as string) === 'prices-detail') return <Detail job={selected!} setView={setView} unitValue={profile.unitValue} />
    if (view === 'my-list') return <MyList setView={setView} setSelected={setSelected} jobs={jobs} unitValue={profile.unitValue} />
    if (view === 'admin') return <Admin view={view} setView={setView} />
    if (view === 'clients') return <ClientsUpdated customers={customers} />
    if (view === 'lists') return <AdminData type="lists" />
    if (view === 'ipc') return <IpcAdmin />
    if (view === 'profile') return <Profile setView={setView} profile={profile} subscription={subscription} />
    if (view === 'subscription') return <div className="mx-auto max-w-[760px] p-5 pb-28 md:p-8"><p className="text-sm text-[var(--oc-muted)]">Cuenta</p><h1 className="mt-1 text-2xl font-bold text-[var(--oc-ink)]">Mi suscripción</h1><div className="mt-6 rounded-2xl border border-[var(--oc-border)] bg-[var(--oc-surface)] p-5"><div className="flex flex-wrap items-start justify-between gap-4"><div><p className="text-xs font-semibold text-[var(--oc-muted)]">Estado de cuenta</p><p className="mt-1 text-lg font-bold text-[var(--oc-ink)]">{subscription?.planName ?? 'Sin plan'}</p><span className="mt-2 inline-flex rounded-full bg-[var(--oc-success-bg)] px-2.5 py-1 text-xs font-semibold text-[var(--oc-success-text)]">{subscription?.status === 'active' ? 'Activa' : subscription?.status ?? 'Sin plan'}</span></div><div className="text-left sm:text-right"><p className="text-xs text-[var(--oc-muted)]">Próximo vencimiento</p><p className="mt-1 font-bold text-[var(--oc-ink)]">{subscription?.endDate ?? '—'}</p></div></div><form action={handleReportPayment} className="mt-6 border-t border-[var(--oc-border-soft)] pt-5"><h2 className="font-bold text-[var(--oc-ink)]">Informar un pago</h2><p className="mt-1 text-sm text-[var(--oc-muted)]">Cargá el monto transferido y la referencia para que Administración lo concilie.</p><div className="mt-4 grid gap-3 sm:grid-cols-2"><input name="amount" type="number" required placeholder="Monto transferido" className="rounded-xl border border-[var(--oc-border)] bg-transparent px-3 py-3 text-sm text-[var(--oc-ink)] outline-none" /><input name="reference" placeholder="Nº de operación" className="rounded-xl border border-[var(--oc-border)] bg-transparent px-3 py-3 text-sm text-[var(--oc-ink)] outline-none" /></div><button type="submit" disabled={payPending || !subscription} className="mt-4 rounded-xl bg-[var(--oc-brand)] px-4 py-2.5 text-sm font-bold text-white disabled:opacity-60">Informar pago</button>{!subscription && <p className="mt-2 text-xs text-[var(--oc-coral)]">Necesitás una suscripción activa o en prueba antes de informar un pago.</p>}</form></div></div>
    const labels: Record<string, [string, string, typeof Home]> = { budgets: ['Presupuestos', 'Organizá tus trabajos y clientes', FileText], payments: ['Pagos', 'Transferencias y comprobantes', Banknote], users: ['Usuarios', 'Administrá las cuentas de profesionales', Users], lists: ['Listas maestras', 'Oficios y versiones vigentes', BookOpen], reconciliation: ['Conciliación', 'Revisá los pagos informados', Banknote] }
    const [title, eyebrow, Icon] = labels[view] || labels.budgets
    return <SimplePage title={title} eyebrow={eyebrow} icon={Icon} action={view === 'budgets' ? '+ Nuevo presupuesto' : undefined} />
  }

  return <div className="min-h-screen bg-[var(--oc-page)] text-[var(--oc-ink)]"><div className="flex min-h-screen"><Sidebar view={view} setView={setView} admin={isAdmin} /><div className="min-w-0 flex-1"><AppHeader title={isAdmin ? 'Administración' : undefined} onMenu={() => setMenuOpen(true)} name={profile.fullName} />{render()}</div></div><BottomNav view={view} setView={setView} />{menuOpen && <div className="fixed inset-0 z-40 bg-[var(--oc-brand)]/20 md:hidden" onClick={() => setMenuOpen(false)}><div className="h-full w-[280px] bg-[var(--oc-surface-muted)] p-5 shadow-xl" onClick={(e) => e.stopPropagation()}><div className="flex items-center justify-between"><Logo /><button onClick={() => setMenuOpen(false)} aria-label="Cerrar menú"><X className="size-5 text-[var(--oc-muted)]" /></button></div><div className="mt-8 flex flex-col gap-1">{[...navItems, { id: 'subscription' as View, label: 'Suscripción', icon: ShieldCheck }].map(({ id, label, icon: Icon }) => <button key={id} onClick={() => { setView(id); setMenuOpen(false) }} className="flex items-center gap-3 rounded-xl px-3 py-3 text-left text-sm font-semibold text-[var(--oc-muted)] hover:bg-[var(--oc-surface-soft)]"><Icon className="size-[18px]" />{label}</button>)}</div></div></div>}</div>
}
