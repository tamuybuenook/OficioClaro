import { createClient } from '@/lib/supabase/server'
import { getMyList } from '@/lib/services/myList'
import { getMyCustomers } from '@/lib/services/customers'
import { getMySubscription } from '@/lib/services/subscriptions'
import { getMyEnabledTradeIds, getMyTradeLimit } from '@/lib/services/userTrades'
import { AppShell, type Job } from '@/components/app-shell'

export default async function Page() {
  const supabase = await createClient()
  const { data: { user } } = await supabase.auth.getUser()

  const { data: profileRow } = await supabase
    .from('profiles')
    .select('full_name, phone, unit_value')
    .eq('id', user?.id ?? '')
    .maybeSingle()

  const { data: allTrades } = await supabase.from('trades').select('id, name, slug').order('name')

  const [list, customers, subscription, enabledTradeIds, tradeLimit] = await Promise.all([
    getMyList(),
    getMyCustomers().catch(() => []),
    getMySubscription().catch(() => null),
    user ? getMyEnabledTradeIds(user.id) : Promise.resolve([]),
    user ? getMyTradeLimit(user.id) : Promise.resolve(0),
  ])

  const jobs: Job[] = list.map(({ service, pricing }) => ({
    id: service.id,
    name: service.name,
    category: (service as any).categories?.name ?? 'General',
    unit: service.unit_label,
    base: pricing!.basePrice,
    regional: pricing!.referencePrice,
    personal: pricing!.personalPrice,
    module: (service as any).ut_coefficient != null ? `${(service as any).ut_coefficient} UT` : null,
  }))

  const profile = {
    fullName: profileRow?.full_name || user?.email?.split('@')[0] || 'Profesional',
    phone: profileRow?.phone ?? null,
    email: user?.email ?? '',
    unitValue: profileRow?.unit_value ?? 0,
  }

  const trades = { all: allTrades ?? [], enabledIds: enabledTradeIds, limit: tradeLimit }

  return (
    <AppShell
      jobs={jobs}
      profile={profile}
      customers={customers ?? []}
      trades={trades}
      subscription={
        subscription
          ? { id: subscription.id, planName: (subscription as any).plans?.name ?? 'Plan', status: subscription.status, endDate: subscription.end_date }
          : null
      }
    />
  )
}
