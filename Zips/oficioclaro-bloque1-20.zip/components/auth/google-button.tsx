'use client'

import { createClient } from '@/lib/supabase/client'

export function GoogleButton() {
  async function signInWithGoogle() {
    const supabase = createClient()
    await supabase.auth.signInWithOAuth({
      provider: 'google',
      options: { redirectTo: `${window.location.origin}/auth/callback` },
    })
  }

  return (
    <button
      type="button"
      onClick={signInWithGoogle}
      className="flex items-center justify-center gap-2 rounded-xl border border-[var(--oc-border)] bg-[var(--oc-surface)] p-3 text-sm font-semibold text-[var(--oc-ink)]"
    >
      Continuar con Google
    </button>
  )
}
