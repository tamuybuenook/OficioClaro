'use client'

import { useTransition } from 'react'
import { createIpcIndex, applyIpcToAllPriceLists } from '@/lib/actions/ipc'

type Ipc = { id: string; year: number; month: number; value: number; published_date: string; status: string }

export function IpcPanel({ ipcs }: { ipcs: Ipc[] }) {
  const [pending, startTransition] = useTransition()

  function handleCreate(formData: FormData) {
    startTransition(() => { createIpcIndex(formData) })
  }

  function apply(id: string) {
    if (!window.confirm('Esto genera una versión borrador por oficio con el % aplicado. ¿Confirmás?')) return
    startTransition(() => { applyIpcToAllPriceLists(id) })
  }

  return (
    <div>
      <form action={handleCreate} className="mt-5 grid gap-3 rounded-2xl border border-[var(--oc-border)] bg-[var(--oc-surface)] p-4 sm:grid-cols-4">
        <input name="year" type="number" placeholder="Año" required className="rounded-lg border border-[var(--oc-border)] p-2 text-sm" />
        <input name="month" type="number" min={1} max={12} placeholder="Mes (1-12)" required className="rounded-lg border border-[var(--oc-border)] p-2 text-sm" />
        <input name="value" type="number" step="0.01" placeholder="% IPC" required className="rounded-lg border border-[var(--oc-border)] p-2 text-sm" />
        <input name="published_date" type="date" required className="rounded-lg border border-[var(--oc-border)] p-2 text-sm" />
        <button type="submit" disabled={pending} className="sm:col-span-4 rounded-lg bg-[var(--oc-brand)] px-3 py-2 text-sm font-bold text-white disabled:opacity-60">Cargar IPC</button>
      </form>

      <div className="mt-5 overflow-x-auto rounded-2xl border border-[var(--oc-border)] bg-[var(--oc-surface)]">
        <table className="w-full min-w-[500px] text-left text-sm">
          <thead><tr className="border-b border-[var(--oc-border-soft)] text-xs text-[var(--oc-muted)]"><th className="p-3">Período</th><th>%</th><th>Publicado</th><th>Estado</th><th></th></tr></thead>
          <tbody>
            {ipcs.map((i) => (
              <tr key={i.id} className="border-b border-[var(--oc-border-soft)] last:border-0">
                <td className="p-3">{i.month}/{i.year}</td>
                <td>{i.value}%</td>
                <td>{i.published_date}</td>
                <td>{i.status}</td>
                <td>{i.status !== 'applied' && <button disabled={pending} onClick={() => apply(i.id)} className="text-xs font-bold text-[var(--oc-brand)]">Aplicar</button>}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  )
}
