import { signUp } from '@/lib/actions/auth'
import { GoogleButton } from '@/components/auth/google-button'

export default function RegisterPage() {
  return (
    <main className="mx-auto flex min-h-dvh max-w-sm flex-col justify-center gap-4 p-6">
      <h1 className="text-xl font-bold">Crear cuenta</h1>
      <p className="text-xs font-semibold text-[var(--oc-brand)]">30 días gratis</p>
      <GoogleButton />
      <div className="flex items-center gap-3 text-xs text-[var(--oc-muted)]"><span className="h-px flex-1 bg-[var(--oc-border)]" />o con tu email<span className="h-px flex-1 bg-[var(--oc-border)]" /></div>
      <form action={signUp} className="flex flex-col gap-3">
        <input name="full_name" type="text" placeholder="Nombre completo" required className="rounded-lg border p-3" />
        <input name="email" type="email" placeholder="Email" required className="rounded-lg border p-3" />
        <input name="password" type="password" placeholder="Contraseña" required minLength={6} className="rounded-lg border p-3" />
        <button type="submit" className="rounded-lg bg-black p-3 text-white">Registrarme</button>
      </form>
      <a href="/login" className="text-sm underline">Ya tengo cuenta</a>
    </main>
  )
}
