import { createClient } from '@/lib/supabase/server'

export default async function PlanesPage() {
  const supabase = await createClient()
  const { data: plans } = await supabase.from('plans').select('*').order('price')

  return (
    <div>
      <p className="text-sm text-[var(--oc-muted)]"><a href="/admin" className="hover:underline">Admin</a> &gt; Planes</p>
      <h1 className="mt-1 text-2xl font-bold">Planes</h1>
      <div className="mt-5 grid gap-4 sm:grid-cols-3">
        {(plans ?? []).map((p) => (
          <div key={p.id} className="rounded-2xl border border-[var(--oc-border)] bg-[var(--oc-surface)] p-4">
            <p className="font-bold">{p.name}</p>
            <p className="mt-1 text-xl font-bold text-[var(--oc-brand)]">${p.price.toLocaleString('es-AR')}/{p.billing_period === 'monthly' ? 'mes' : 'año'}</p>
            <p className="mt-2 text-sm text-[var(--oc-muted)]">{p.max_trades === null ? 'Todos los oficios' : `${p.max_trades} oficio(s)`}</p>
            <p className="mt-1 text-xs text-[var(--oc-muted)]">{p.trial_days} días gratis · {p.is_active ? 'Activo' : 'Inactivo'}</p>
          </div>
        ))}
      </div>
      <p className="mt-4 text-xs text-[var(--oc-muted)]">Edición desde el panel: próximamente. Por ahora, editar valores directamente en Supabase.</p>
    </div>
  )
}
