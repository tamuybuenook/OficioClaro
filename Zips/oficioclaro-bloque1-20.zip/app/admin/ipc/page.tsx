import { createClient } from '@/lib/supabase/server'
import { IpcPanel } from '@/components/admin/ipc-panel'

export default async function IpcPage() {
  const supabase = await createClient()
  const { data: ipcs } = await supabase.from('ipc_indexes').select('*').order('published_date', { ascending: false })

  return (
    <div>
      <p className="text-sm text-[var(--oc-muted)]"><a href="/admin" className="hover:underline">Admin</a> &gt; IPC</p>
      <h1 className="mt-1 text-2xl font-bold">IPC y actualizaciones</h1>
      <p className="mt-1 text-sm text-[var(--oc-muted)]">Publicado en un mes → aplica al mes siguiente.</p>
      <IpcPanel ipcs={ipcs ?? []} />
    </div>
  )
}
