import { createClient } from '@/lib/supabase/server'

export default async function UsuariosPage() {
  const supabase = await createClient()
  const { data: users } = await supabase
    .from('profiles')
    .select('id, full_name, role, created_at')
    .order('created_at', { ascending: false })
    .limit(200)

  return (
    <div>
      <p className="text-sm text-[var(--oc-muted)]"><a href="/admin" className="hover:underline">Admin</a> &gt; Usuarios</p>
      <h1 className="mt-1 text-2xl font-bold">Usuarios ({users?.length ?? 0})</h1>
      <div className="mt-5 overflow-x-auto rounded-2xl border border-[var(--oc-border)] bg-[var(--oc-surface)]">
        <table className="w-full min-w-[500px] text-left text-sm">
          <thead><tr className="border-b border-[var(--oc-border-soft)] text-xs text-[var(--oc-muted)]"><th className="p-3">Nombre</th><th>Rol</th><th>Alta</th></tr></thead>
          <tbody>
            {(users ?? []).map((u) => (
              <tr key={u.id} className="border-b border-[var(--oc-border-soft)] last:border-0">
                <td className="p-3">{u.full_name || '—'}</td>
                <td>{u.role}</td>
                <td>{new Date(u.created_at).toLocaleDateString('es-AR')}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  )
}
