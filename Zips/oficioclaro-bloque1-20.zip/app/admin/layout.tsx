import { requireAdmin } from '@/lib/auth/require-admin'

const groups = [
  { label: null, links: [{ href: '/admin', label: 'Inicio' }] },
  { label: 'Catálogo', links: [{ href: '/admin/catalogo', label: 'Listas maestras / Oficios' }] },
  { label: 'Usuarios', links: [{ href: '/admin/usuarios', label: 'Usuarios' }] },
  { label: 'Negocio', links: [{ href: '/admin/planes', label: 'Planes' }, { href: '/admin/suscripciones', label: 'Suscripciones' }] },
  { label: 'Actualizaciones', links: [{ href: '/admin/ipc', label: 'IPC' }] },
  { label: 'Sistema', links: [{ href: '/admin/configuracion', label: 'Configuración' }] },
]

export default async function AdminLayout({ children }: { children: React.ReactNode }) {
  await requireAdmin()

  return (
    <div className="flex min-h-dvh bg-[var(--oc-page)] text-[var(--oc-ink)]">
      <aside className="hidden w-[240px] shrink-0 flex-col border-r border-[var(--oc-border)] bg-[var(--oc-surface-muted)] px-4 py-6 md:flex">
        <p className="px-2 text-sm font-bold text-[var(--oc-brand)]">OficioClaro admin</p>
        <nav className="mt-8 flex flex-col gap-4">
          {groups.map((g) => (
            <div key={g.label ?? 'root'}>
              {g.label && <p className="px-2 text-[11px] font-bold uppercase tracking-wide text-[var(--oc-muted)]">{g.label}</p>}
              <div className="mt-1 flex flex-col gap-0.5">
                {g.links.map((l) => (
                  <a key={l.href} href={l.href} className="rounded-lg px-2 py-2 text-sm font-semibold text-[var(--oc-ink)] hover:bg-[var(--oc-surface-soft)]">{l.label}</a>
                ))}
              </div>
            </div>
          ))}
        </nav>
        <a href="/" className="mt-auto rounded-lg border border-[var(--oc-border)] px-3 py-2 text-center text-sm font-semibold text-[var(--oc-muted)]">Salir de Admin</a>
      </aside>
      <div className="min-w-0 flex-1 p-5 md:p-8">{children}</div>
    </div>
  )
}
