import { createClient } from '@/lib/supabase/server'

export default async function AdminHome() {
  const supabase = await createClient()

  const [{ count: users }, { count: activeSubs }, { count: pendingPayments }, { count: trades }] = await Promise.all([
    supabase.from('profiles').select('id', { count: 'exact', head: true }),
    supabase.from('subscriptions').select('id', { count: 'exact', head: true }).in('status', ['trial', 'active']),
    supabase.from('payments').select('id', { count: 'exact', head: true }).eq('status', 'pending'),
    supabase.from('trades').select('id', { count: 'exact', head: true }),
  ])

  const stats = [
    ['Usuarios', users ?? 0],
    ['Suscripciones activas/trial', activeSubs ?? 0],
    ['Pagos pendientes', pendingPayments ?? 0],
    ['Oficios cargados', trades ?? 0],
  ] as const

  return (
    <div>
      <p className="text-sm text-[var(--oc-muted)]">Admin</p>
      <h1 className="mt-1 text-2xl font-bold">Inicio</h1>
      <div className="mt-6 grid grid-cols-2 gap-3 lg:grid-cols-4">
        {stats.map(([label, value]) => (
          <div key={label} className="rounded-2xl border border-[var(--oc-border)] bg-[var(--oc-surface)] p-4">
            <p className="text-xs text-[var(--oc-muted)]">{label}</p>
            <p className="mt-1 text-2xl font-bold">{value}</p>
          </div>
        ))}
      </div>
    </div>
  )
}
