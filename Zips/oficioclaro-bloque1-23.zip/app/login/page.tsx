import { signIn } from '@/lib/actions/auth'
import { GoogleButton } from '@/components/auth/google-button'
import { createClient } from '@/lib/supabase/server'
import { redirect } from 'next/navigation'

export default async function LoginPage() {
  const supabase = await createClient()
  const { data: { user } } = await supabase.auth.getUser()
  if (user) redirect('/')

  return (
    <main className="mx-auto flex min-h-dvh max-w-sm flex-col justify-center gap-4 bg-[var(--oc-page)] p-6 text-[var(--oc-ink)]">
      <div>
        <p className="text-xs font-bold uppercase tracking-[0.2em] text-[var(--oc-brand)]">OficioClaro</p>
        <h1 className="mt-1 text-2xl font-bold">Iniciar sesión</h1>
      </div>
      <GoogleButton />
      <div className="flex items-center gap-3 text-xs text-[var(--oc-muted)]"><span className="h-px flex-1 bg-[var(--oc-border)]" />o con tu email<span className="h-px flex-1 bg-[var(--oc-border)]" /></div>
      <form action={signIn} className="flex flex-col gap-3">
        <input name="email" type="email" placeholder="Email" required className="rounded-xl border border-[var(--oc-border)] bg-transparent p-3 text-sm outline-none" />
        <input name="password" type="password" placeholder="Contraseña" required className="rounded-xl border border-[var(--oc-border)] bg-transparent p-3 text-sm outline-none" />
        <button type="submit" className="rounded-xl bg-[var(--oc-brand)] p-3 text-sm font-bold text-white">Entrar</button>
      </form>
      <a href="/register" className="text-center text-sm font-semibold text-[var(--oc-brand)] underline">Crear cuenta</a>
    </main>
  )
}
