'use client'

import { useState, useTransition } from 'react'
import { createIpcIndex, applyIpcToAllPriceLists } from '@/lib/actions/ipc'
import { CalendarDays } from 'lucide-react'

type Ipc = { id: string; year: number; month: number; value: number; published_date: string; status: string }

export function IpcPanel({ ipcs }: { ipcs: Ipc[] }) {
  const [pending, startTransition] = useTransition()
  const [percent, setPercent] = useState('')
  const [year, setYear] = useState(String(new Date().getFullYear()))
  const [month, setMonth] = useState('')
  const [published, setPublished] = useState('')
  const [message, setMessage] = useState<string | null>(null)

  const last = ipcs[0]
  const pendingIpc = ipcs.find((i) => i.status !== 'applied')

  function handleCreate() {
    if (!percent || !month || !published) { setMessage('Completá todos los campos.'); return }
    const fd = new FormData()
    fd.set('year', year)
    fd.set('month', month)
    fd.set('value', percent)
    fd.set('published_date', published)
    startTransition(async () => {
      const res = await createIpcIndex(fd)
      if (res && 'error' in res) { setMessage(res.error); return }
      setMessage('IPC guardado.')
      setPercent(''); setMonth(''); setPublished('')
    })
  }

  function apply(id: string) {
    if (!window.confirm('Esto genera una versión borrador por oficio con el % aplicado. ¿Confirmás?')) return
    startTransition(async () => {
      const res = await applyIpcToAllPriceLists(id)
      setMessage('error' in res ? res.error : 'IPC aplicado: nuevas versiones generadas en borrador.')
    })
  }

  return (
    <div className="mx-auto max-w-[1040px]">
      <div className="mt-6 grid gap-3 sm:grid-cols-2">
        <div className="rounded-2xl border border-[var(--oc-border)] bg-[var(--oc-surface)] p-5">
          <p className="text-xs font-semibold text-[var(--oc-muted)]">Último IPC cargado</p>
          {last ? (
            <>
              <p className="mt-2 text-3xl font-bold text-[var(--oc-brand)]">{last.value}%</p>
              <p className="mt-3 text-sm text-[var(--oc-muted)]">Publicado <strong className="text-[var(--oc-ink)]">{last.published_date}</strong></p>
              <p className="mt-1 text-sm text-[var(--oc-muted)]">Estado: <strong className="text-[var(--oc-ink)]">{last.status}</strong></p>
            </>
          ) : <p className="mt-2 text-sm text-[var(--oc-muted)]">Todavía no cargaste ningún IPC.</p>}
        </div>
        <div className="rounded-2xl border border-[var(--oc-border)] bg-[var(--oc-surface)] p-5">
          <p className="text-xs font-semibold text-[var(--oc-muted)]">Pendiente de aplicar</p>
          <p className="mt-2 text-xl font-bold text-[var(--oc-ink)]">{pendingIpc ? `${pendingIpc.value}% · ${pendingIpc.month}/${pendingIpc.year}` : 'Ninguno'}</p>
        </div>
      </div>

      <section className="mt-5 rounded-2xl border border-[var(--oc-border)] bg-[var(--oc-surface)] p-5">
        <div className="flex items-center gap-3">
          <div className="rounded-xl bg-[var(--oc-brand-soft)] p-3 text-[var(--oc-brand)]"><CalendarDays className="size-5" /></div>
          <div>
            <h2 className="font-bold text-[var(--oc-ink)]">Cargar nuevo IPC</h2>
            <p className="text-sm text-[var(--oc-muted)]">El mes de aplicación se calcula automáticamente a partir de la fecha de publicación.</p>
          </div>
        </div>
        <div className="mt-5 grid gap-4 sm:grid-cols-4">
          <label className="text-sm font-semibold text-[var(--oc-ink)]">% IPC<input value={percent} onChange={(e) => setPercent(e.target.value)} inputMode="decimal" className="mt-2 w-full rounded-xl border border-[var(--oc-border)] bg-transparent px-3 py-3 font-normal text-[var(--oc-ink)] outline-none" placeholder="4.2" /></label>
          <label className="text-sm font-semibold text-[var(--oc-ink)]">Año<input value={year} onChange={(e) => setYear(e.target.value)} type="number" className="mt-2 w-full rounded-xl border border-[var(--oc-border)] bg-transparent px-3 py-3 font-normal text-[var(--oc-ink)] outline-none" /></label>
          <label className="text-sm font-semibold text-[var(--oc-ink)]">Mes (1-12)<input value={month} onChange={(e) => setMonth(e.target.value)} type="number" min={1} max={12} className="mt-2 w-full rounded-xl border border-[var(--oc-border)] bg-transparent px-3 py-3 font-normal text-[var(--oc-ink)] outline-none" /></label>
          <label className="text-sm font-semibold text-[var(--oc-ink)]">Fecha de publicación<input value={published} onChange={(e) => setPublished(e.target.value)} type="date" className="mt-2 w-full rounded-xl border border-[var(--oc-border)] bg-transparent px-3 py-3 font-normal text-[var(--oc-ink)] outline-none" /></label>
        </div>
        <button disabled={pending} onClick={handleCreate} className="mt-5 rounded-xl bg-[var(--oc-brand)] px-4 py-2.5 text-sm font-bold text-white disabled:opacity-60">Guardar IPC</button>
        {message && <p className="mt-3 text-sm font-semibold text-[var(--oc-ink)]">{message}</p>}
      </section>

      <section className="mt-5 rounded-2xl border border-[var(--oc-border)] bg-[var(--oc-surface)] p-5">
        <h2 className="font-bold text-[var(--oc-ink)]">Historial de IPC</h2>
        <p className="mt-1 text-sm text-[var(--oc-muted)]">Las listas anteriores permanecen intactas.</p>
        <div className="mt-4 overflow-x-auto">
          <table className="w-full min-w-[560px] text-left text-sm">
            <thead><tr className="border-b border-[var(--oc-border-soft)] text-xs text-[var(--oc-muted)]"><th className="px-3 py-3">IPC</th><th>Período</th><th>Publicado</th><th>Estado</th><th></th></tr></thead>
            <tbody>
              {ipcs.map((row) => (
                <tr key={row.id} className="border-b border-[var(--oc-border-soft)] last:border-0">
                  <td className="px-3 py-4 font-bold text-[var(--oc-brand)]">{row.value}%</td>
                  <td className="text-[var(--oc-ink)]">{row.month}/{row.year}</td>
                  <td className="text-[var(--oc-muted)]">{row.published_date}</td>
                  <td className="text-[var(--oc-ink)]">{row.status}</td>
                  <td>{row.status !== 'applied' && <button disabled={pending} onClick={() => apply(row.id)} className="text-xs font-bold text-[var(--oc-brand)]">Aplicar</button>}</td>
                </tr>
              ))}
              {ipcs.length === 0 && <tr><td colSpan={5} className="p-4 text-sm text-[var(--oc-muted)]">Sin registros todavía.</td></tr>}
            </tbody>
          </table>
        </div>
      </section>
    </div>
  )
}
