import { createClient } from '@/lib/supabase/server'
import { UsuariosPanel } from '@/components/admin/usuarios-panel'

export default async function UsuariosPage() {
  const supabase = await createClient()
  const { data: users } = await supabase
    .from('profiles')
    .select('id, full_name, role, created_at')
    .order('created_at', { ascending: false })
    .limit(200)

  return (
    <div>
      <p className="text-sm text-[var(--oc-muted)]"><a href="/admin" className="hover:underline">Admin</a> &gt; Usuarios</p>
      <h1 className="mt-1 text-2xl font-bold">Usuarios ({users?.length ?? 0})</h1>
      <UsuariosPanel users={users ?? []} />
    </div>
  )
}
