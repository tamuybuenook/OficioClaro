'use client'

import { useState, useTransition } from 'react'
import { updateUser, deleteUser } from '@/lib/actions/adminUsers'

type User = { id: string; full_name: string | null; role: string; created_at: string }

export function UsuariosPanel({ users }: { users: User[] }) {
  const [editing, setEditing] = useState<string | null>(null)
  const [pending, startTransition] = useTransition()
  const [error, setError] = useState<string | null>(null)

  function save(userId: string, formData: FormData) {
    startTransition(async () => {
      const res = await updateUser(userId, formData)
      if (res && 'error' in res) setError(res.error)
      setEditing(null)
    })
  }

  function remove(userId: string, name: string) {
    if (!window.confirm(`¿Borrar a ${name || 'este usuario'}? Es permanente.`)) return
    startTransition(async () => {
      const res = await deleteUser(userId)
      if (res && 'error' in res) setError(res.error)
    })
  }

  return (
    <div>
      {error && <p className="mt-3 rounded-xl bg-[#fdecea] p-3 text-sm font-semibold text-[var(--oc-coral)]">{error}</p>}
      <div className="mt-5 overflow-x-auto rounded-2xl border border-[var(--oc-border)] bg-[var(--oc-surface)]">
        <table className="w-full min-w-[560px] text-left text-sm">
          <thead><tr className="border-b border-[var(--oc-border-soft)] text-xs text-[var(--oc-muted)]"><th className="p-3">Nombre</th><th>Rol</th><th>Alta</th><th></th></tr></thead>
          <tbody>
            {users.map((u) => (
              <tr key={u.id} className="border-b border-[var(--oc-border-soft)] last:border-0">
                {editing === u.id ? (
                  <td colSpan={4} className="p-3">
                    <form action={(fd) => save(u.id, fd)} className="flex flex-wrap items-center gap-2">
                      <input name="full_name" defaultValue={u.full_name ?? ''} placeholder="Nombre" className="rounded-lg border border-[var(--oc-border)] p-2 text-sm" />
                      <select name="role" defaultValue={u.role} className="rounded-lg border border-[var(--oc-border)] p-2 text-sm">
                        <option value="user">user</option>
                        <option value="admin">admin</option>
                      </select>
                      <button type="submit" disabled={pending} className="rounded-lg bg-[var(--oc-brand)] px-3 py-2 text-xs font-bold text-white disabled:opacity-60">Guardar</button>
                      <button type="button" onClick={() => setEditing(null)} className="rounded-lg border border-[var(--oc-border)] px-3 py-2 text-xs font-bold">Cancelar</button>
                    </form>
                  </td>
                ) : (
                  <>
                    <td className="p-3">{u.full_name || '—'}</td>
                    <td>{u.role}</td>
                    <td>{new Date(u.created_at).toLocaleDateString('es-AR')}</td>
                    <td className="flex gap-3 p-3">
                      <button onClick={() => setEditing(u.id)} className="text-xs font-bold text-[var(--oc-brand)]">Editar</button>
                      <button disabled={pending} onClick={() => remove(u.id, u.full_name ?? '')} className="text-xs font-bold text-[var(--oc-coral)]">Borrar</button>
                    </td>
                  </>
                )}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  )
}
