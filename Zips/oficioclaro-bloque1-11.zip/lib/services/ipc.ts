import { createClient } from '@/lib/supabase/server'

export async function getIpcIndexes() {
  const supabase = await createClient()
  const { data, error } = await supabase.from('ipc_indexes').select('*').order('year', { ascending: false }).order('month', { ascending: false })
  if (error) throw error
  return data
}

const MESES = ['enero', 'febrero', 'marzo', 'abril', 'mayo', 'junio', 'julio', 'agosto', 'septiembre', 'octubre', 'noviembre', 'diciembre']

// Regla sección 8: IPC de agosto -> impacta la lista de octubre (mes + 2).
export function targetEffectiveDate(year: number, month: number): { date: string; label: string } {
  const base = new Date(Date.UTC(year, month - 1, 1))
  base.setUTCMonth(base.getUTCMonth() + 2)
  const y = base.getUTCFullYear()
  const m = base.getUTCMonth() // 0-indexed
  const date = `${y}-${String(m + 1).padStart(2, '0')}-01`
  const label = `${MESES[m][0].toUpperCase()}${MESES[m].slice(1)} ${y}`
  return { date, label }
}
