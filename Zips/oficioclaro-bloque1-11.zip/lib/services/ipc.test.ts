import { describe, it, expect } from 'vitest'
import { targetEffectiveDate } from './ipc'

describe('targetEffectiveDate', () => {
  it('IPC agosto impacta la lista de octubre (sección 8)', () => {
    expect(targetEffectiveDate(2026, 8)).toEqual({ date: '2026-10-01', label: 'Octubre 2026' })
  })
  it('cruza de año: IPC noviembre impacta enero del año siguiente', () => {
    expect(targetEffectiveDate(2026, 11)).toEqual({ date: '2027-01-01', label: 'Enero 2027' })
  })
  it('IPC diciembre impacta febrero del año siguiente', () => {
    expect(targetEffectiveDate(2026, 12)).toEqual({ date: '2027-02-01', label: 'Febrero 2027' })
  })
})
