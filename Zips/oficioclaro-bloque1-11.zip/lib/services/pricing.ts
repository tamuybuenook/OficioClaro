import { createClient } from '@/lib/supabase/server'

export function round2(n: number): number {
  return Math.round(n * 100) / 100
}

// PRECIO GENERAL + AJUSTE REGIONAL = PRECIO DE REFERENCIA (sección 10)
export function applyRegionalAdjustment(basePrice: number, adjustmentPercent: number): number {
  return round2(basePrice * (1 + adjustmentPercent / 100))
}

// coeficiente UT × valor UT del profesional (sección 12)
export function calculateUtPrice(coefficient: number, unitValue: number): number {
  return round2(coefficient * unitValue)
}

// "Mi precio": prioridad = personalizado explícito > sugerido por UT > referencia (sección 11)
export function resolvePersonalPrice(params: {
  customPrice?: number | null
  utCoefficient?: number | null
  unitValue?: number | null
  referencePrice: number
}): { price: number; source: 'custom' | 'ut' | 'reference' } {
  if (params.customPrice != null) return { price: params.customPrice, source: 'custom' }
  if (params.utCoefficient != null && params.unitValue) {
    return { price: calculateUtPrice(params.utCoefficient, params.unitValue), source: 'ut' }
  }
  return { price: params.referencePrice, source: 'reference' }
}

export interface ServicePricing {
  serviceId: string
  basePrice: number
  regionAdjustmentPercent: number
  referencePrice: number
  personalPrice: number
  personalSource: 'custom' | 'ut' | 'reference'
}

// Orquestador: junta lista vigente + zona del usuario + precio personalizado.
export async function getServicePricing(serviceId: string, userId?: string | null): Promise<ServicePricing | null> {
  const supabase = await createClient()

  const { data: service, error: serviceError } = await supabase
    .from('services')
    .select('id, ut_coefficient, category_id, categories(trade_id)')
    .eq('id', serviceId)
    .single()
  if (serviceError || !service) return null

  const tradeId = (service as any).categories?.trade_id
  const { data: priceList } = await supabase.from('price_lists').select('id').eq('trade_id', tradeId).maybeSingle()
  if (!priceList) return null

  const { data: version } = await supabase
    .from('price_list_versions')
    .select('id')
    .eq('price_list_id', priceList.id)
    .eq('status', 'published')
    .lte('effective_date', new Date().toISOString().slice(0, 10))
    .order('effective_date', { ascending: false })
    .limit(1)
    .maybeSingle()
  if (!version) return null

  const { data: item } = await supabase
    .from('price_items')
    .select('base_price')
    .eq('price_list_version_id', version.id)
    .eq('service_id', serviceId)
    .maybeSingle()
  if (!item) return null

  let adjustmentPercent = 0
  let unitValue: number | null = null
  let customPrice: number | null = null

  if (userId) {
    const { data: profile } = await supabase
      .from('profiles')
      .select('region_id, unit_value, regions(adjustment_percent)')
      .eq('id', userId)
      .maybeSingle()
    unitValue = profile?.unit_value ?? null
    adjustmentPercent = (profile as any)?.regions?.adjustment_percent ?? 0

    const { data: userItem } = await supabase
      .from('user_price_items')
      .select('custom_price')
      .eq('user_id', userId)
      .eq('service_id', serviceId)
      .maybeSingle()
    customPrice = userItem?.custom_price ?? null
  }

  const referencePrice = applyRegionalAdjustment(item.base_price, adjustmentPercent)
  const personal = resolvePersonalPrice({
    customPrice,
    utCoefficient: service.ut_coefficient,
    unitValue,
    referencePrice,
  })

  return {
    serviceId,
    basePrice: item.base_price,
    regionAdjustmentPercent: adjustmentPercent,
    referencePrice,
    personalPrice: personal.price,
    personalSource: personal.source,
  }
}
