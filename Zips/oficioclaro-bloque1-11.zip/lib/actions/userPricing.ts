'use server'

import { createClient } from '@/lib/supabase/server'
import { revalidatePath } from 'next/cache'

// Guarda/actualiza "mi precio" para un servicio. No toca la lista general ni el IPC (sección 13).
export async function setMyPrice(serviceId: string, customPrice: number) {
  const supabase = await createClient()
  const { data: { user } } = await supabase.auth.getUser()
  if (!user) return { error: 'No autenticado' }

  const { error } = await supabase
    .from('user_price_items')
    .upsert(
      { user_id: user.id, service_id: serviceId, custom_price: customPrice, updated_at: new Date().toISOString() },
      { onConflict: 'user_id,service_id' },
    )
  if (error) return { error: error.message }
  revalidatePath('/mi-lista')
}

// Vuelve a usar el precio de referencia (deja de estar personalizado).
export async function resetMyPrice(serviceId: string) {
  const supabase = await createClient()
  const { data: { user } } = await supabase.auth.getUser()
  if (!user) return { error: 'No autenticado' }

  const { error } = await supabase.from('user_price_items').delete().eq('user_id', user.id).eq('service_id', serviceId)
  if (error) return { error: error.message }
  revalidatePath('/mi-lista')
}

// Cambia el valor de la UT: recalcula automáticamente todos los trabajos vinculados
// (no se guarda nada extra: pricing.ts lee profiles.unit_value en el momento).
export async function setMyUnitValue(unitValue: number) {
  const supabase = await createClient()
  const { data: { user } } = await supabase.auth.getUser()
  if (!user) return { error: 'No autenticado' }

  const { error } = await supabase
    .from('profiles')
    .update({ unit_value: unitValue, updated_at: new Date().toISOString() })
    .eq('id', user.id)
  if (error) return { error: error.message }
  revalidatePath('/mi-lista')
  revalidatePath('/perfil')
}
