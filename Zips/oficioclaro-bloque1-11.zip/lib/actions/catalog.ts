'use server'

import { createClient } from '@/lib/supabase/server'
import { revalidatePath } from 'next/cache'

async function logAudit(entity: string, entityId: string | null, action: string, newValue: unknown) {
  const supabase = await createClient()
  const { data: { user } } = await supabase.auth.getUser()
  await supabase.from('audit_logs').insert({
    actor_id: user?.id ?? null,
    entity,
    entity_id: entityId,
    action,
    new_value: newValue,
  })
}

// ---------- trades ----------
export async function createTrade(formData: FormData) {
  const supabase = await createClient()
  const name = String(formData.get('name'))
  const slug = String(formData.get('slug'))
  const { data, error } = await supabase.from('trades').insert({ name, slug }).select().single()
  if (error) return { error: error.message }
  await logAudit('trades', data.id, 'create', data)
  revalidatePath('/admin/oficios')
  return { data }
}

export async function updateTrade(id: string, formData: FormData) {
  const supabase = await createClient()
  const name = String(formData.get('name'))
  const slug = String(formData.get('slug'))
  const { error } = await supabase.from('trades').update({ name, slug }).eq('id', id)
  if (error) return { error: error.message }
  await logAudit('trades', id, 'update', { name, slug })
  revalidatePath('/admin/oficios')
}

export async function deleteTrade(id: string) {
  const supabase = await createClient()
  const { error } = await supabase.from('trades').delete().eq('id', id)
  if (error) return { error: error.message }
  await logAudit('trades', id, 'delete', null)
  revalidatePath('/admin/oficios')
}

// ---------- categories ----------
export async function createCategory(tradeId: string, formData: FormData) {
  const supabase = await createClient()
  const name = String(formData.get('name'))
  const { data, error } = await supabase
    .from('categories')
    .insert({ trade_id: tradeId, name })
    .select()
    .single()
  if (error) return { error: error.message }
  await logAudit('categories', data.id, 'create', data)
  revalidatePath('/admin/oficios')
  return { data }
}

export async function deleteCategory(id: string) {
  const supabase = await createClient()
  const { error } = await supabase.from('categories').delete().eq('id', id)
  if (error) return { error: error.message }
  await logAudit('categories', id, 'delete', null)
  revalidatePath('/admin/oficios')
}

// ---------- services ----------
export async function createService(categoryId: string, formData: FormData) {
  const supabase = await createClient()
  const name = String(formData.get('name'))
  const unit_label = String(formData.get('unit_label') || 'Trabajo')
  const utRaw = formData.get('ut_coefficient')
  const ut_coefficient = utRaw ? Number(utRaw) : null

  const { data, error } = await supabase
    .from('services')
    .insert({ category_id: categoryId, name, unit_label, ut_coefficient })
    .select()
    .single()
  if (error) return { error: error.message }
  await logAudit('services', data.id, 'create', data)
  revalidatePath('/admin/oficios')
  return { data }
}

export async function updateService(id: string, formData: FormData) {
  const supabase = await createClient()
  const name = String(formData.get('name'))
  const unit_label = String(formData.get('unit_label') || 'Trabajo')
  const utRaw = formData.get('ut_coefficient')
  const ut_coefficient = utRaw ? Number(utRaw) : null

  const { error } = await supabase
    .from('services')
    .update({ name, unit_label, ut_coefficient })
    .eq('id', id)
  if (error) return { error: error.message }
  await logAudit('services', id, 'update', { name, unit_label, ut_coefficient })
  revalidatePath('/admin/oficios')
}

export async function deleteService(id: string) {
  const supabase = await createClient()
  const { error } = await supabase.from('services').delete().eq('id', id)
  if (error) return { error: error.message }
  await logAudit('services', id, 'delete', null)
  revalidatePath('/admin/oficios')
}
