'use server'

import { createClient } from '@/lib/supabase/server'
import { revalidatePath } from 'next/cache'

export async function updateMyProfile(formData: FormData) {
  const supabase = await createClient()
  const { data: { user } } = await supabase.auth.getUser()
  if (!user) return { error: 'No autenticado' }

  const full_name = String(formData.get('full_name') ?? '')
  const phone = String(formData.get('phone') ?? '')
  const region_id = formData.get('region_id') ? String(formData.get('region_id')) : null

  const { error } = await supabase
    .from('profiles')
    .update({ full_name, phone, region_id, updated_at: new Date().toISOString() })
    .eq('id', user.id)
  if (error) return { error: error.message }
  revalidatePath('/perfil')
}
