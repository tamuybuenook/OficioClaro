'use server'

import { createClient } from '@/lib/supabase/server'
import { round2 } from '@/lib/services/pricing'
import { targetEffectiveDate } from '@/lib/services/ipc'
import { revalidatePath } from 'next/cache'

async function logAudit(entity: string, entityId: string | null, action: string, newValue: unknown) {
  const supabase = await createClient()
  const { data: { user } } = await supabase.auth.getUser()
  await supabase.from('audit_logs').insert({ actor_id: user?.id ?? null, entity, entity_id: entityId, action, new_value: newValue })
}

export async function createIpcIndex(formData: FormData) {
  const supabase = await createClient()
  const year = Number(formData.get('year'))
  const month = Number(formData.get('month'))
  const value = Number(formData.get('value'))
  const published_date = String(formData.get('published_date'))

  const { data, error } = await supabase
    .from('ipc_indexes')
    .insert({ year, month, value, published_date, status: 'pending' })
    .select()
    .single()
  if (error) return { error: error.message }
  await logAudit('ipc_indexes', data.id, 'create', data)
  revalidatePath('/admin/ipc')
  return { data }
}

// Genera, para cada oficio, una versión BORRADOR con los precios de la última
// versión publicada + el % de IPC. No publica automáticamente (sección 8/9).
export async function applyIpcToAllPriceLists(ipcId: string) {
  const supabase = await createClient()

  const { data: ipc, error: ipcError } = await supabase.from('ipc_indexes').select('*').eq('id', ipcId).single()
  if (ipcError || !ipc) return { error: ipcError?.message ?? 'IPC no encontrado' }

  const { date: effective_date, label: version_label } = targetEffectiveDate(ipc.year, ipc.month)

  const { data: priceLists, error: listsError } = await supabase.from('price_lists').select('id')
  if (listsError) return { error: listsError.message }

  const createdVersions: string[] = []

  for (const list of priceLists ?? []) {
    const { data: baseVersion } = await supabase
      .from('price_list_versions')
      .select('id')
      .eq('price_list_id', list.id)
      .eq('status', 'published')
      .lte('effective_date', new Date().toISOString().slice(0, 10))
      .order('effective_date', { ascending: false })
      .limit(1)
      .maybeSingle()
    if (!baseVersion) continue // oficio sin lista vigente todavía: se carga manualmente

    const { data: newVersion, error: versionError } = await supabase
      .from('price_list_versions')
      .insert({ price_list_id: list.id, version_label, status: 'draft', effective_date, source_ipc_id: ipcId })
      .select()
      .single()
    if (versionError) continue // ya existe una versión con ese label para este oficio

    const { data: baseItems } = await supabase
      .from('price_items')
      .select('service_id, base_price')
      .eq('price_list_version_id', baseVersion.id)
    if (baseItems?.length) {
      const rows = baseItems.map((i) => ({
        price_list_version_id: newVersion.id,
        service_id: i.service_id,
        base_price: round2(i.base_price * (1 + ipc.value / 100)),
      }))
      await supabase.from('price_items').insert(rows)
    }
    createdVersions.push(newVersion.id)
  }

  await supabase.from('ipc_indexes').update({ status: 'applied' }).eq('id', ipcId)
  await logAudit('ipc_indexes', ipcId, 'apply', { createdVersions })
  revalidatePath('/admin/ipc')
  revalidatePath('/admin/listas')
  return { data: createdVersions }
}
