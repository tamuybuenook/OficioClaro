'use server'

import { createClient } from '@/lib/supabase/server'
import { getServicePricing } from '@/lib/services/pricing'
import { round2 } from '@/lib/services/pricing'
import { revalidatePath } from 'next/cache'

async function logActivity(customerId: string | null, type: string, description?: string) {
  if (!customerId) return
  const supabase = await createClient()
  const { data: { user } } = await supabase.auth.getUser()
  if (!user) return
  await supabase.from('client_activity').insert({ user_id: user.id, customer_id: customerId, type, description })
}

import { getMyQuotes, getQuoteWithItems } from '@/lib/services/quotes'
import { requireFullAccess } from '@/lib/services/access'

export async function fetchMyQuotes() {
  return getMyQuotes()
}

export async function fetchQuoteDetail(quoteId: string) {
  return getQuoteWithItems(quoteId)
}

export async function createQuote(customerId: string | null) {
  const denied = await requireFullAccess()
  if (denied) return { error: denied.error }
  const supabase = await createClient()
  const { data: { user } } = await supabase.auth.getUser()
  if (!user) return { error: 'No autenticado' }

  const { count } = await supabase.from('quotes').select('id', { count: 'exact', head: true }).eq('user_id', user.id)
  const number = (count ?? 0) + 1

  const { data, error } = await supabase
    .from('quotes')
    .insert({ user_id: user.id, customer_id: customerId, total: 0, number, status: 'draft' })
    .select()
    .single()
  if (error) return { error: error.message }
  await logActivity(customerId, 'presupuesto_creado', `Presupuesto Nº ${String(number).padStart(5, '0')}`)
  revalidatePath('/presupuestos')
  return { data }
}

export async function setQuoteStatus(quoteId: string, customerId: string | null, status: 'draft' | 'sent' | 'accepted' | 'rejected') {
  const denied = await requireFullAccess()
  if (denied) return { error: denied.error }
  const supabase = await createClient()
  const { error } = await supabase.from('quotes').update({ status }).eq('id', quoteId)
  if (error) return { error: error.message }
  const labels: Record<string, string> = { sent: 'presupuesto_enviado', accepted: 'presupuesto_aceptado', rejected: 'presupuesto_rechazado', draft: 'presupuesto_creado' }
  await logActivity(customerId, labels[status])
  revalidatePath('/presupuestos')
  revalidatePath('/clientes')
}

async function recalculateTotal(quoteId: string) {
  const supabase = await createClient()
  const { data: items } = await supabase.from('quote_items').select('subtotal').eq('quote_id', quoteId)
  const total = round2((items ?? []).reduce((sum, i) => sum + Number(i.subtotal), 0))
  await supabase.from('quotes').update({ total }).eq('id', quoteId)
}

// Agrega un ítem usando "mi precio" (personalizado/UT/referencia, sección 11) como precio unitario por defecto.
export async function addQuoteItem(quoteId: string, serviceId: string, quantity: number) {
  const denied = await requireFullAccess()
  if (denied) return { error: denied.error }
  const supabase = await createClient()
  const { data: { user } } = await supabase.auth.getUser()
  const pricing = await getServicePricing(serviceId, user?.id)
  if (!pricing) return { error: 'El servicio no tiene un precio vigente.' }

  const subtotal = round2(pricing.personalPrice * quantity)
  const { data: service } = await supabase.from('services').select('name').eq('id', serviceId).maybeSingle()
  const row = {
    quote_id: quoteId,
    service_id: serviceId,
    quantity,
    unit_price: pricing.personalPrice,
    subtotal,
  }
  // description: copia histórica del nombre del servicio (migración 0022). Si la columna todavía no
  // existe, se inserta igual sin ella para no frenar la presupuestación.
  let { error } = await supabase.from('quote_items').insert({ ...row, description: service?.name ?? null })
  if (error && (error.code === '42703' || error.code === 'PGRST204')) {
    ;({ error } = await supabase.from('quote_items').insert(row))
  }
  if (error) return { error: error.message }

  await recalculateTotal(quoteId)
  revalidatePath(`/presupuestos/${quoteId}`)
}

export async function updateQuoteItemQuantity(itemId: string, quoteId: string, quantity: number) {
  const denied = await requireFullAccess()
  if (denied) return { error: denied.error }
  const supabase = await createClient()
  const { data: item, error: itemError } = await supabase.from('quote_items').select('unit_price').eq('id', itemId).single()
  if (itemError || !item) return { error: itemError?.message ?? 'Ítem no encontrado' }

  const subtotal = round2(item.unit_price * quantity)
  const { error } = await supabase.from('quote_items').update({ quantity, subtotal }).eq('id', itemId)
  if (error) return { error: error.message }

  await recalculateTotal(quoteId)
  revalidatePath(`/presupuestos/${quoteId}`)
}

export async function removeQuoteItem(itemId: string, quoteId: string) {
  const denied = await requireFullAccess()
  if (denied) return { error: denied.error }
  const supabase = await createClient()
  const { error } = await supabase.from('quote_items').delete().eq('id', itemId)
  if (error) return { error: error.message }

  await recalculateTotal(quoteId)
  revalidatePath(`/presupuestos/${quoteId}`)
}

export async function deleteQuote(quoteId: string) {
  const denied = await requireFullAccess()
  if (denied) return { error: denied.error }
  const supabase = await createClient()
  const { error } = await supabase.from('quotes').delete().eq('id', quoteId)
  if (error) return { error: error.message }
  revalidatePath('/presupuestos')
}
